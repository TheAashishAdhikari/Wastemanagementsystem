<?php
require "config.php";

$pageTitle = "Create Account";
require "header.php";
?>

<style>
.sw-register-page {
    --reg-green: #176348;
    --reg-dark: #113f31;
    --reg-lime: #d8ee97;
    --reg-text: #20382b;
    --reg-muted: #506456;
    --reg-border: #d8e2d5;

    color: var(--reg-text);
    font-family: Arial, Helvetica, sans-serif;
    font-size: 16px;
    line-height: 1.6;
}

.sw-register-page *,
.sw-register-page *::before,
.sw-register-page *::after {
    box-sizing: border-box;
}

.sw-register-page [hidden] {
    display: none !important;
}

.sw-register-page h1,
.sw-register-page h2,
.sw-register-page h3,
.sw-register-page p {
    margin: 0;
}

.sw-register-page .reg-layout {
    display: grid;
    grid-template-columns: 0.8fr 1.2fr;
    border: 1px solid var(--reg-border);
    border-radius: 22px;
    background: #fff;
    box-shadow: 0 16px 45px rgba(17, 63, 49, 0.06);
    overflow: hidden;
}

/* Introduction */
.sw-register-page .reg-intro {
    display: flex;
    flex-direction: column;
    padding: 45px 35px;
    background:
        radial-gradient(ellipse at top left, #2a6549, transparent 65%),
        var(--reg-dark);
    color: #fff;
}

.sw-register-page .reg-brand-icon {
    display: grid;
    place-items: center;
    width: 65px;
    height: 65px;
    margin-bottom: 35px;
    border: 1px solid #ffffff35;
    border-radius: 18px;
    background: #ffffff0d;
    color: var(--reg-lime);
    font-size: 42px;
    line-height: 1;
}

.sw-register-page .reg-eyebrow {
    display: block;
    margin-bottom: 14px;
    color: var(--reg-green);
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
}

.sw-register-page .reg-intro .reg-eyebrow {
    color: var(--reg-lime);
}

.sw-register-page .reg-intro h2 {
    font-size: clamp(30px, 3.5vw, 43px);
    line-height: 1.15;
    letter-spacing: -1px;
}

.sw-register-page .reg-intro > p {
    margin-top: 22px;
    color: #e0ece2;
    font-size: 16px;
    line-height: 1.85;
}

.sw-register-page .reg-benefits {
    display: grid;
    gap: 25px;
    margin: 35px 0;
    padding: 0;
    list-style: none;
}

.sw-register-page .reg-benefits li {
    display: flex;
    align-items: flex-start;
    gap: 13px;
}

.sw-register-page .reg-check {
    display: grid;
    place-items: center;
    flex: 0 0 27px;
    height: 27px;
    margin-top: 2px;
    border-radius: 50%;
    background: #ffffff15;
    color: var(--reg-lime);
    font-size: 15px;
}

.sw-register-page .reg-benefits strong {
    display: block;
    margin-bottom: 5px;
    font-size: 16px;
}

.sw-register-page .reg-benefits p {
    color: #d7e6da;
    font-size: 15px;
    line-height: 1.75;
}

.sw-register-page .reg-intro-footer {
    margin-top: auto;
    padding-top: 25px;
    border-top: 1px solid #ffffff30;
    color: #e0ece2;
    font-size: 14px;
}

/* Registration form */
.sw-register-page .reg-content {
    min-width: 0;
    padding: 42px;
}

.sw-register-page h1 {
    font-size: clamp(29px, 3vw, 36px);
    line-height: 1.2;
    letter-spacing: -0.8px;
}

.sw-register-page .reg-description {
    margin-top: 12px;
    color: var(--reg-muted);
    font-size: 16px;
    line-height: 1.8;
}

.sw-register-page .reg-required-note {
    margin-top: 15px;
    color: var(--reg-muted);
    font-size: 14px;
}

.sw-register-page .reg-required {
    color: #9b3e2c;
}

.sw-register-page form {
    margin-top: 30px;
}

.sw-register-page .reg-fieldset {
    min-width: 0;
    margin: 0 0 27px;
    padding: 0;
    border: 0;
}

.sw-register-page .reg-fieldset legend {
    width: 100%;
    margin-bottom: 20px;
    padding: 0 0 11px;
    border-bottom: 1px solid #e4eae0;
    color: var(--reg-dark);
    font-size: 18px;
    font-weight: 700;
}

.sw-register-page .reg-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 21px 18px;
}

.sw-register-page .reg-field {
    min-width: 0;
}

.sw-register-page .reg-full {
    grid-column: 1 / -1;
}

.sw-register-page .reg-field label {
    display: block;
    margin-bottom: 8px;
    color: #304b38;
    font-size: 15px;
    font-weight: 700;
}

.sw-register-page .reg-optional {
    color: #586b5d;
    font-size: 13px;
    font-weight: 400;
}

.sw-register-page .reg-field input,
.sw-register-page .reg-field select {
    display: block;
    width: 100%;
    min-height: 50px;
    margin: 0;
    padding: 13px 14px;
    border: 1px solid #cddac8;
    border-radius: 9px;
    background: #fcfdf9;
    color: var(--reg-text);
    font-family: inherit;
    font-size: 16px;
    line-height: 1.5;
}

.sw-register-page .reg-field input::placeholder {
    color: #69756b;
    opacity: 1;
}

.sw-register-page .reg-field input:focus,
.sw-register-page .reg-field select:focus {
    outline: 2px solid #72995a;
    outline-offset: 2px;
    border-color: var(--reg-green);
    background: #fff;
}

.sw-register-page .reg-help {
    margin-top: 8px;
    color: var(--reg-muted);
    font-size: 14px;
    line-height: 1.65;
}

.sw-register-page .reg-role-note {
    padding: 14px 16px;
    border: 1px solid #d9e4cd;
    border-radius: 9px;
    background: #f0f5e9;
    color: #3f5e36;
    font-size: 14px;
    line-height: 1.75;
}

.sw-register-page .reg-password-option {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 19px;
    color: #35523e;
    font-size: 15px;
    cursor: pointer;
}

.sw-register-page .reg-password-option input {
    width: 18px;
    height: 18px;
    margin: 0;
    accent-color: var(--reg-green);
}

.sw-register-page .reg-error {
    margin-top: 8px;
    color: #a02e25;
    font-size: 14px;
}

.sw-register-page .reg-submit {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 18px;
    width: 100%;
    min-height: 53px;
    padding: 14px 20px;
    border: 0;
    border-radius: 9px;
    background: var(--reg-green);
    color: #fff;
    font-family: inherit;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
}

.sw-register-page .reg-submit:hover {
    background: var(--reg-dark);
}

.sw-register-page .reg-login-link {
    margin-top: 24px;
    padding-top: 23px;
    border-top: 1px solid #e4eae0;
    color: var(--reg-muted);
    font-size: 15px;
    text-align: center;
}

.sw-register-page .reg-login-link a {
    color: var(--reg-green);
    font-weight: 700;
    text-underline-offset: 4px;
}

.sw-register-page button:focus-visible,
.sw-register-page a:focus-visible,
.sw-register-page input[type="checkbox"]:focus-visible {
    outline: 3px solid #72995a;
    outline-offset: 4px;
}

@media (max-width: 1000px) {
    .sw-register-page .reg-layout {
        grid-template-columns: 0.75fr 1.25fr;
    }

    .sw-register-page .reg-intro,
    .sw-register-page .reg-content {
        padding: 30px;
    }
}

@media (max-width: 800px) {
    .sw-register-page .reg-layout {
        grid-template-columns: 1fr;
    }

    .sw-register-page .reg-brand-icon {
        margin-bottom: 22px;
    }

    .sw-register-page .reg-benefits {
        gap: 18px;
        margin: 25px 0;
    }

    .sw-register-page .reg-intro h2 {
        max-width: 520px;
    }
}

@media (max-width: 520px) {
    .sw-register-page .reg-intro,
    .sw-register-page .reg-content {
        padding: 25px 20px;
    }

    .sw-register-page .reg-grid {
        grid-template-columns: 1fr;
    }

    .sw-register-page .reg-layout {
        border-radius: 15px;
    }
}
</style>

<div class="sw-register-page">
    <div class="reg-layout">

        <!-- Introduction -->
        <aside class="reg-intro" aria-labelledby="reg-intro-title">
            <div class="reg-brand-icon" aria-hidden="true">♻</div>

            <span class="reg-eyebrow">Smart Waste Management</span>

            <h2 id="reg-intro-title">
                Be part of a<br>
                cleaner tomorrow.
            </h2>

            <p>
                Join a connected community working together to report,
                collect and recover waste responsibly.
            </p>

            <ul class="reg-benefits">
                <li>
                    <span class="reg-check" aria-hidden="true">✓</span>
                    <div>
                        <strong>Make a local difference</strong>
                        <p>
                            Help bring waste issues to attention and
                            support cleaner shared spaces.
                        </p>
                    </div>
                </li>

                <li>
                    <span class="reg-check" aria-hidden="true">✓</span>
                    <div>
                        <strong>Find your role</strong>
                        <p>
                            Participate as a citizen, waste collector
                            or recycling company.
                        </p>
                    </div>
                </li>

                <li>
                    <span class="reg-check" aria-hidden="true">✓</span>
                    <div>
                        <strong>Stay connected</strong>
                        <p>
                            Access the dashboard and tools relevant
                            to your account.
                        </p>
                    </div>
                </li>
            </ul>

            <div class="reg-intro-footer">
                SDG 11 · Sustainable Cities and Communities
            </div>
        </aside>

        <!-- Registration -->
        <section class="reg-content" aria-labelledby="reg-title">
            <span class="reg-eyebrow">Get started</span>

            <h1 id="reg-title">Create your account</h1>

            <p class="reg-description">
                Enter your details and choose how you would like
                to use the platform.
            </p>

            <p class="reg-required-note">
                Fields marked <span class="reg-required">*</span>
                are required.
            </p>

            <form action="register_action.php"
                  method="POST"
                  id="reg-form">

                <fieldset class="reg-fieldset">
                    <legend>Your details</legend>

                    <div class="reg-grid">
                        <div class="reg-field">
                            <label for="reg-name">
                                Full Name
                                <span class="reg-required" aria-hidden="true">*</span>
                            </label>

                            <input
                                type="text"
                                id="reg-name"
                                name="name"
                                placeholder="Enter your full name"
                                autocomplete="name"
                                required
                            >
                        </div>

                        <div class="reg-field">
                            <label for="reg-email">
                                Email Address
                                <span class="reg-required" aria-hidden="true">*</span>
                            </label>

                            <input
                                type="email"
                                id="reg-email"
                                name="email"
                                placeholder="you@example.com"
                                autocomplete="email"
                                required
                            >
                        </div>

                        <div class="reg-field">
                            <label for="reg-phone">
                                Phone
                                <span class="reg-optional">(optional)</span>
                            </label>

                            <input
                                type="tel"
                                id="reg-phone"
                                name="phone"
                                placeholder="Enter your phone number"
                                autocomplete="tel"
                            >
                        </div>

                        <div class="reg-field">
                            <label for="reg-address">
                                Address
                                <span class="reg-optional">(optional)</span>
                            </label>

                            <input
                                type="text"
                                id="reg-address"
                                name="address"
                                placeholder="Enter your address"
                                autocomplete="street-address"
                            >
                        </div>
                    </div>
                </fieldset>

                <fieldset class="reg-fieldset">
                    <legend>Your account</legend>

                    <div class="reg-grid">
                        <div class="reg-field reg-full">
                            <label for="reg-role">
                                Account Type
                                <span class="reg-required" aria-hidden="true">*</span>
                            </label>

                            <select name="role" id="reg-role" required>
                                <option value="Citizen">Citizen</option>
                                <option value="Collector">Waste Collector</option>
                                <option value="Recycler">Recycling Company</option>
                            </select>
                        </div>

                        <p class="reg-role-note reg-full"
                           id="reg-role-description"
                           role="status"
                           hidden></p>

                        <div class="reg-field reg-full"
                             id="reg-company-field">
                            <label for="reg-company">
                                Company Name
                                <span class="reg-optional">
                                    (for recycling companies)
                                </span>
                            </label>

                            <input
                                type="text"
                                id="reg-company"
                                name="company_name"
                                placeholder="Enter your company name"
                                autocomplete="organization"
                            >
                        </div>
                    </div>
                </fieldset>

                <fieldset class="reg-fieldset">
                    <legend>Your password</legend>

                    <div class="reg-grid">
                        <div class="reg-field">
                            <label for="reg-password">
                                Password
                                <span class="reg-required" aria-hidden="true">*</span>
                            </label>

                            <input
                                type="password"
                                id="reg-password"
                                name="password"
                                placeholder="Create a password"
                                autocomplete="new-password"
                                minlength="8"
                                aria-describedby="reg-password-help"
                                required
                            >

                            <p class="reg-help" id="reg-password-help">
                                Use at least 8 characters.
                            </p>
                        </div>

                        <div class="reg-field">
                            <label for="reg-confirm">
                                Confirm Password
                                <span class="reg-required" aria-hidden="true">*</span>
                            </label>

                            <input
                                type="password"
                                id="reg-confirm"
                                name="confirm_password"
                                placeholder="Repeat your password"
                                autocomplete="new-password"
                                minlength="8"
                                aria-describedby="reg-password-error"
                                required
                            >

                            <p class="reg-error"
                               id="reg-password-error"
                               aria-live="polite"></p>
                        </div>
                    </div>

                    <label class="reg-password-option"
                           id="reg-password-option"
                           hidden>
                        <input type="checkbox" id="reg-show-passwords">
                        Show passwords
                    </label>
                </fieldset>

                <button type="submit" class="reg-submit">
                    Create Account
                    <span aria-hidden="true">→</span>
                </button>

                <p class="reg-login-link">
                    Already have an account?
                    <a href="index.php#sw-login">Sign in</a>
                </p>
            </form>
        </section>

    </div>
</div>

<script>
(() => {
    "use strict";

    const role = document.getElementById("reg-role");
    const roleDescription = document.getElementById("reg-role-description");
    const companyField = document.getElementById("reg-company-field");
    const companyInput = document.getElementById("reg-company");

    const password = document.getElementById("reg-password");
    const confirmation = document.getElementById("reg-confirm");
    const passwordError = document.getElementById("reg-password-error");
    const passwordOption = document.getElementById("reg-password-option");
    const showPasswords = document.getElementById("reg-show-passwords");

    const descriptions = {
        Citizen:
            "Report waste issues, request pickups and track collection progress.",
        Collector:
            "View assigned pickups, manage collection tasks and update job status.",
        Recycler:
            "View recyclable waste listings, request collections and maintain recycling records."
    };

    function updateRole() {
        const isRecycler = role.value === "Recycler";

        roleDescription.textContent = descriptions[role.value] || "";
        companyField.hidden = !isRecycler;
        companyInput.disabled = !isRecycler;
    }

    function checkPasswords() {
        const mismatch = confirmation.value !== "" &&
            confirmation.value !== password.value;

        confirmation.setCustomValidity(
            mismatch ? "Your passwords do not match." : ""
        );

        confirmation.setAttribute("aria-invalid", String(mismatch));

        passwordError.textContent = mismatch
            ? "Passwords do not match. Please check both fields."
            : "";
    }

    roleDescription.hidden = false;
    passwordOption.hidden = false;

    role.addEventListener("change", updateRole);

    showPasswords.addEventListener("change", () => {
        const type = showPasswords.checked ? "text" : "password";

        password.type = type;
        confirmation.type = type;
    });

    password.addEventListener("input", checkPasswords);
    confirmation.addEventListener("input", checkPasswords);

    // Also synchronise fields when returning using the browser's Back button.
    window.addEventListener("pageshow", () => {
        updateRole();
        checkPasswords();
    });

    updateRole();
})();
</script>

<?php require "footer.php"; ?>