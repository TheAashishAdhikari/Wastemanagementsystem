<?php
require "config.php";

$user = currentUser();

if ($user) {
    header("Location: " . dashboardPage($user["role"]));
    exit();
}

$pageTitle = "Smart Waste Management";
require "header.php";
?>

<style>
/* Everything is scoped to this homepage. */
.sw-home {
    --green: #176348;
    --green-dark: #113f31;
    --lime: #d8ee97;
    --ink: #172e26;
    --muted: #63736a;
    --line: #dfe7df;
    --paper: #f6f8f2;
    font-family: Arial, Helvetica, sans-serif;
    color: var(--ink);
    background: var(--paper);
    border-radius: 24px;
    overflow: hidden;
}

.sw-home *,
.sw-home *::before,
.sw-home *::after {
    box-sizing: border-box;
}

.sw-home h1,
.sw-home h2,
.sw-home h3,
.sw-home p {
    margin: 0;
}

.sw-home a {
    color: inherit;
}

.sw-home button,
.sw-home input {
    font: inherit;
}

.sw-home a:focus-visible,
.sw-home button:focus-visible,
.sw-home summary:focus-visible {
    outline: 3px solid #679d35;
    outline-offset: 5px;
}

.sw-home .sw-wrap {
    width: min(1120px, 90%);
    margin: 0 auto;
}

.sw-home .sw-section {
    padding: 80px 0;
}

.sw-home .sw-label {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    color: var(--green);
    font-size: 11px;
    font-weight: 800;
    letter-spacing: 1.8px;
    text-transform: uppercase;
}

.sw-home .sw-label::before {
    content: "";
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: currentColor;
}

.sw-home h2 {
    margin-top: 15px;
    font-size: clamp(28px, 3.5vw, 42px);
    line-height: 1.15;
    letter-spacing: -1.5px;
}

.sw-home .sw-copy {
    color: var(--muted);
    font-size: 15px;
    line-height: 1.85;
}

.sw-home .sw-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 18px;
    min-height: 49px;
    padding: 13px 23px;
    border: 1px solid transparent;
    border-radius: 9px;
    background: var(--green);
    color: #fff;
    font-size: 14px;
    font-weight: 700;
    text-decoration: none;
    cursor: pointer;
    transition: background .2s, transform .2s;
}

.sw-home .sw-btn:hover {
    background: var(--green-dark);
    transform: translateY(-2px);
}

.sw-home .sw-btn-light {
    background: #fff;
    color: var(--green-dark);
    border-color: var(--line);
}

.sw-home .sw-btn-light:hover {
    background: #edf2e8;
}

.sw-home .sw-btn-lime {
    background: var(--lime);
    color: var(--green-dark);
}

.sw-home .sw-btn-lime:hover {
    background: #c5e77a;
}

/* Hero */
.sw-home .sw-hero {
    position: relative;
    padding: 75px 0 65px;
    background:
        radial-gradient(ellipse at 90% 15%, #e4efcf 0, transparent 50%),
        var(--paper);
}

.sw-home .sw-hero-grid {
    display: grid;
    grid-template-columns: 1.15fr 1fr;
    align-items: center;
    gap: 65px;
}

.sw-home .sw-hero h1 {
    margin: 22px 0;
    font-size: clamp(40px, 5.3vw, 68px);
    line-height: 1.05;
    letter-spacing: -3px;
    font-weight: 800;
}

.sw-home .sw-hero h1 span {
    color: var(--green);
}

.sw-home .sw-hero .sw-copy {
    max-width: 480px;
    font-size: 16px;
}

.sw-home .sw-actions {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin-top: 29px;
}

.sw-home .sw-hero-note {
    margin-top: 24px;
    color: var(--muted);
    font-size: 12px;
    line-height: 1.7;
}

.sw-home .sw-hero-art {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 435px;
    padding: 30px;
    border-radius: 28px;
    color: #fff;
    background: var(--green-dark);
    overflow: hidden;
}

.sw-home .sw-art-ring {
    position: absolute;
    width: 350px;
    height: 350px;
    border: 1px solid #ffffff18;
    border-radius: 50%;
}

.sw-home .sw-art-ring::after {
    content: "";
    position: absolute;
    inset: 32px;
    border: 1px solid #ffffff15;
    border-radius: 50%;
}

.sw-home .sw-art-top {
    position: absolute;
    top: 25px;
    left: 25px;
    color: #d2e4d8;
    font-size: 10px;
    letter-spacing: 2px;
}

.sw-home .sw-art-tag {
    position: absolute;
    z-index: 2;
    padding: 12px 16px;
    background: #f6f8f2;
    color: var(--green-dark);
    border-radius: 10px;
    box-shadow: 0 12px 25px #00000015;
    font-size: 12px;
    font-weight: 700;
}

.sw-home .sw-tag-left {
    top: 115px;
    left: 20px;
    transform: rotate(-7deg);
}

.sw-home .sw-tag-right {
    right: 18px;
    bottom: 115px;
    transform: rotate(6deg);
    background: var(--lime);
}

.sw-home .sw-art-bottom {
    position: absolute;
    bottom: 25px;
    color: #d2e4d8;
    font-size: 11px;
    letter-spacing: 1.5px;
}

/* Decorative bottle */
.sw-home .sw-bottle {
    position: relative;
    z-index: 1;
    width: 145px;
    height: 275px;
    will-change: transform;
}

.sw-home .sw-bottle-cap {
    width: 57px;
    height: 24px;
    margin: auto;
    border-radius: 7px 7px 3px 3px;
    background: repeating-linear-gradient(
        90deg,
        #b4d37a 0,
        #b4d37a 5px,
        #cee996 5px,
        #cee996 9px
    );
}

.sw-home .sw-bottle-neck {
    width: 48px;
    height: 25px;
    margin: auto;
    border: 2px solid #cee6ce;
    border-top: 0;
    background: #ffffff12;
}

.sw-home .sw-bottle-body {
    position: relative;
    height: 225px;
    border: 2px solid #cee6ce;
    border-radius: 40px 40px 24px 24px;
    background: linear-gradient(110deg, #ffffff24, #ffffff06 55%, #ffffff20);
    overflow: hidden;
    box-shadow: inset 8px 0 15px #ffffff08, 12px 20px 30px #00000015;
}

.sw-home .sw-bottle-body::after {
    content: "";
    position: absolute;
    left: 14px;
    top: 25px;
    width: 6px;
    height: 70px;
    border-radius: 8px;
    background: #ffffff35;
}

.sw-home .sw-bottle-label {
    position: absolute;
    z-index: 2;
    top: 73px;
    left: 0;
    width: 100%;
    padding: 10px;
    background: var(--lime);
    color: var(--green-dark);
    text-align: center;
}

.sw-home .sw-bottle-label strong {
    display: block;
    font-size: 35px;
    line-height: 1;
}

.sw-home .sw-bottle-label span {
    font-size: 8px;
    font-weight: 800;
    letter-spacing: 2px;
}

.sw-home .sw-particles {
    position: absolute;
    inset: 0;
}

.sw-home .sw-particle {
    position: absolute;
    width: 7px;
    height: 7px;
    background: #cde88d;
    border-radius: 2px;
    opacity: .75;
    animation: sw-float var(--duration) ease-in-out infinite alternate;
    animation-delay: var(--delay);
}

@keyframes sw-float {
    to {
        transform: translate(var(--drift), -12px) rotate(65deg);
    }
}

/* Overview strip */
.sw-home .sw-overview {
    border-top: 1px solid var(--line);
    border-bottom: 1px solid var(--line);
    background: #edf2e7;
}

.sw-home .sw-overview-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
}

.sw-home .sw-overview-item {
    padding: 27px 20px;
    border-right: 1px solid var(--line);
}

.sw-home .sw-overview-item:last-child {
    border: 0;
}

.sw-home .sw-overview-item strong {
    display: block;
    margin-bottom: 6px;
    font-size: 21px;
    letter-spacing: -.5px;
}

.sw-home .sw-overview-item span {
    color: var(--muted);
    font-size: 12px;
}

/* Section headings and cards */
.sw-home .sw-section-top {
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 30px;
    margin-bottom: 32px;
}

.sw-home .sw-section-top > p {
    max-width: 330px;
}

.sw-home .sw-services {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
}

.sw-home .sw-service {
    padding: 29px;
    border: 1px solid var(--line);
    border-radius: 16px;
    background: #fff;
}

.sw-home .sw-icon {
    display: grid;
    place-items: center;
    width: 47px;
    height: 47px;
    margin-bottom: 26px;
    border-radius: 12px;
    background: #edf3e4;
    color: var(--green);
}

.sw-home .sw-icon svg {
    width: 23px;
    height: 23px;
}

.sw-home h3 {
    font-size: 19px;
    letter-spacing: -.4px;
}

.sw-home .sw-service p {
    margin-top: 12px;
    font-size: 14px;
}

.sw-home .sw-service-foot {
    margin-top: 23px;
    padding-top: 16px;
    border-top: 1px solid var(--line);
    color: var(--green);
    font-size: 12px;
    font-weight: 700;
}

/* Process */
.sw-home .sw-process {
    color: #fff;
    background: var(--green-dark);
}

.sw-home .sw-process .sw-label {
    color: var(--lime);
}

.sw-home .sw-process .sw-copy {
    color: #c2d3c8;
}

.sw-home .sw-steps {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 25px;
    margin-top: 40px;
}

.sw-home .sw-step {
    border-top: 1px solid #ffffff30;
    padding-top: 23px;
}

.sw-home .sw-step-number {
    display: block;
    margin-bottom: 25px;
    color: var(--lime);
    font-size: 13px;
    font-weight: 700;
}

.sw-home .sw-step p {
    margin-top: 13px;
    font-size: 13px;
}

/* Login */
.sw-home .sw-access-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    align-items: center;
    gap: 80px;
}

.sw-home .sw-access-copy > p {
    margin-top: 22px;
}

.sw-home .sw-benefits {
    display: grid;
    gap: 20px;
    margin: 28px 0 0;
    padding: 0;
    list-style: none;
}

.sw-home .sw-benefits li {
    display: flex;
    align-items: flex-start;
    gap: 13px;
}

.sw-home .sw-check {
    display: grid;
    place-items: center;
    flex: 0 0 25px;
    height: 25px;
    border-radius: 50%;
    background: #e4edda;
    color: var(--green);
    font-size: 13px;
}

.sw-home .sw-benefits strong {
    display: block;
    margin: 3px 0 5px;
    font-size: 14px;
}

.sw-home .sw-benefits p {
    color: var(--muted);
    font-size: 13px;
    line-height: 1.7;
}

.sw-home .sw-login {
    padding: 35px;
    border: 1px solid var(--line);
    border-radius: 20px;
    background: #fff;
    box-shadow: 0 15px 45px #183b2510;
    scroll-margin-top: 30px;
}

.sw-home .sw-login h2 {
    font-size: 28px;
    letter-spacing: -1px;
}

.sw-home .sw-login > p {
    margin-top: 10px;
    font-size: 13px;
}

.sw-home .sw-login form {
    margin-top: 26px;
}

.sw-home .sw-login label {
    display: block;
    margin: 18px 0 9px;
    font-size: 12px;
    font-weight: 700;
}

.sw-home .sw-login input {
    display: block;
    width: 100%;
    min-height: 49px;
    padding: 13px 14px;
    border: 1px solid #d8e1d9;
    border-radius: 8px;
    background: #fafbf8;
    color: var(--ink);
    font-size: 14px;
}

.sw-home .sw-login input:focus {
    outline: 2px solid #8aaf72;
    outline-offset: 2px;
}

.sw-home .sw-password-field {
    position: relative;
}

.sw-home .sw-password-field input {
    padding-right: 70px;
}

.sw-home .sw-password-toggle {
    position: absolute;
    top: 5px;
    right: 5px;
    min-height: 39px;
    padding: 0 12px;
    border: 0;
    border-radius: 5px;
    background: transparent;
    color: var(--green);
    font-size: 12px;
    font-weight: 700;
    cursor: pointer;
}

.sw-home .sw-login-submit {
    width: 100%;
    margin-top: 23px;
}

.sw-home .sw-register {
    margin-top: 23px;
    padding-top: 22px;
    border-top: 1px solid var(--line);
    text-align: center;
    color: var(--muted);
    font-size: 12px;
    line-height: 1.8;
}

.sw-home .sw-register a {
    color: var(--green);
    font-weight: 700;
}

/* Users */
.sw-home .sw-users-section {
    border-top: 1px solid var(--line);
    background: #eef2e8;
}

.sw-home .sw-users {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
}

.sw-home .sw-user {
    padding: 25px;
    border: 1px solid var(--line);
    border-radius: 14px;
    background: #fff;
}

.sw-home .sw-role-number {
    display: block;
    margin-bottom: 25px;
    color: #718765;
    font-size: 12px;
    font-weight: 700;
}

.sw-home .sw-user h3 {
    font-size: 17px;
}

.sw-home .sw-user p {
    margin-top: 12px;
    font-size: 13px;
}

/* FAQ */
.sw-home .sw-faq-grid {
    display: grid;
    grid-template-columns: .8fr 1.2fr;
    gap: 70px;
}

.sw-home .sw-faq-intro p {
    margin-top: 20px;
}

.sw-home .sw-faq details {
    border-bottom: 1px solid var(--line);
}

.sw-home .sw-faq summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 22px 0;
    font-size: 14px;
    font-weight: 700;
    line-height: 1.5;
    list-style: none;
    cursor: pointer;
}

.sw-home .sw-faq summary::-webkit-details-marker {
    display: none;
}

.sw-home .sw-faq summary::after {
    content: "+";
    color: var(--green);
    font-size: 23px;
}

.sw-home .sw-faq details[open] summary::after {
    content: "−";
}

.sw-home .sw-faq details p {
    padding: 0 28px 23px 0;
    font-size: 14px;
}

/* Closing call to action */
.sw-home .sw-cta {
    margin-bottom: 55px;
    padding: 42px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 30px;
    border-radius: 20px;
    background: var(--lime);
}

.sw-home .sw-cta h2 {
    margin: 0;
    font-size: clamp(26px, 3vw, 36px);
}

.sw-home .sw-cta p {
    margin-top: 12px;
    max-width: 540px;
    color: #3b5434;
    font-size: 14px;
    line-height: 1.7;
}

.sw-home .sw-cta .sw-btn {
    flex-shrink: 0;
}

@media (max-width: 1000px) {
    .sw-home .sw-hero-grid,
    .sw-home .sw-access-grid {
        gap: 35px;
    }

    .sw-home .sw-users {
        grid-template-columns: repeat(2, 1fr);
    }

    .sw-home .sw-services {
        gap: 12px;
    }

    .sw-home .sw-service {
        padding: 23px;
    }

    .sw-home .sw-faq-grid {
        gap: 35px;
    }
}

@media (max-width: 760px) {
    .sw-home {
        border-radius: 16px;
    }

    .sw-home .sw-section {
        padding: 55px 0;
    }

    .sw-home .sw-hero {
        padding: 48px 0;
    }

    .sw-home .sw-hero-grid,
    .sw-home .sw-access-grid,
    .sw-home .sw-faq-grid,
    .sw-home .sw-services {
        grid-template-columns: 1fr;
    }

    .sw-home .sw-hero h1 {
        letter-spacing: -2px;
    }

    .sw-home .sw-hero-art {
        min-height: 380px;
        margin-top: 10px;
    }

    .sw-home .sw-section-top {
        display: block;
    }

    .sw-home .sw-section-top > p {
        margin-top: 18px;
        max-width: none;
    }

    .sw-home .sw-overview-grid,
    .sw-home .sw-steps {
        grid-template-columns: repeat(2, 1fr);
    }

    .sw-home .sw-overview-item:nth-child(2) {
        border-right: 0;
    }

    .sw-home .sw-overview-item:nth-child(-n+2) {
        border-bottom: 1px solid var(--line);
    }

    .sw-home .sw-login {
        padding: 27px;
    }

    .sw-home .sw-cta {
        padding: 29px;
        flex-direction: column;
        align-items: flex-start;
    }
}

@media (max-width: 420px) {
    .sw-home .sw-users,
    .sw-home .sw-steps {
        grid-template-columns: 1fr;
    }

    .sw-home .sw-art-tag {
        padding: 10px;
        font-size: 10px;
    }

    .sw-home .sw-tag-left {
        left: 9px;
    }

    .sw-home .sw-tag-right {
        right: 9px;
    }

    .sw-home .sw-actions .sw-btn {
        width: 100%;
    }

    .sw-home .sw-overview-item {
        padding: 22px 12px;
    }
}

@media (prefers-reduced-motion: reduce) {
    .sw-home .sw-particle {
        animation: none;
    }

    .sw-home .sw-btn {
        transition: none;
    }

    .sw-home .sw-bottle {
        transform: none !important;
        will-change: auto;
    }
}
</style>

<div class="sw-home">

    <!-- HERO -->
    <section class="sw-hero" aria-labelledby="sw-hero-title">
        <div class="sw-wrap sw-hero-grid">

            <div>
                <span class="sw-label">
                    Smart Waste Management · SDG 11
                </span>

                <h1 id="sw-hero-title">
                    Cleaner streets.<br>
                    <span>Better tomorrow.</span>
                </h1>

                <p class="sw-copy">
                    Make responsible waste management part of everyday life.
                    Report waste, request collections and connect recyclable
                    materials with the people who can give them a second life.
                </p>

                <div class="sw-actions">
                    <a href="register.php" class="sw-btn">
                        Get Started <span aria-hidden="true">↗</span>
                    </a>

                    <a href="#sw-how-it-works" class="sw-btn sw-btn-light">
                        How It Works <span aria-hidden="true">↓</span>
                    </a>
                </div>

                <p class="sw-hero-note">
                    Connecting citizens, waste collectors, recycling
                    companies and administrators.
                </p>
            </div>

            <div class="sw-hero-art" aria-hidden="true">
                <span class="sw-art-top">SMALL ACTIONS. SHARED RESPONSIBILITY.</span>

                <div class="sw-art-ring"></div>

                <div class="sw-art-tag sw-tag-left">
                    Give waste a second life
                </div>

                <div class="sw-bottle" id="sw-scroll-bottle">
                    <div class="sw-bottle-cap"></div>
                    <div class="sw-bottle-neck"></div>

                    <div class="sw-bottle-body">
                        <div class="sw-particles" id="sw-particles"></div>

                        <div class="sw-bottle-label">
                            <strong>♻</strong>
                            <span>RECYCLE &amp; REUSE</span>
                        </div>
                    </div>
                </div>

                <div class="sw-art-tag sw-tag-right">
                    Less waste. More possibility.
                </div>

                <span class="sw-art-bottom">REDUCE / REUSE / RECYCLE</span>
            </div>

        </div>
    </section>

    <!-- PLATFORM OVERVIEW -->
    <section class="sw-overview" aria-label="Platform overview">
        <div class="sw-wrap sw-overview-grid">

            <div class="sw-overview-item">
                <strong>4 user roles</strong>
                <span>Working towards cleaner communities</span>
            </div>

            <div class="sw-overview-item">
                <strong>Report &amp; collect</strong>
                <span>Coordinate waste pickup requests</span>
            </div>

            <div class="sw-overview-item">
                <strong>Recover &amp; reuse</strong>
                <span>Support responsible recycling</span>
            </div>

            <div class="sw-overview-item">
                <strong>SDG 11</strong>
                <span>Sustainable cities and communities</span>
            </div>

        </div>
    </section>

    <!-- SERVICES -->
    <section class="sw-section" aria-labelledby="sw-services-title">
        <div class="sw-wrap">

            <div class="sw-section-top">
                <div>
                    <span class="sw-label">What you can do</span>
                    <h2 id="sw-services-title">
                        Better waste management<br>
                        starts with a simple action.
                    </h2>
                </div>

                <p class="sw-copy">
                    Bring reporting, collection and recycling together
                    in one connected platform.
                </p>
            </div>

            <div class="sw-services">

                <article class="sw-service">
                    <div class="sw-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="1.7"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z"/>
                            <circle cx="12" cy="10" r="2.5"/>
                        </svg>
                    </div>

                    <h3>Report a Waste Issue</h3>

                    <p class="sw-copy">
                        Help identify waste that needs attention. Submit
                        location details, describe the issue and attach
                        photos to support your report.
                    </p>

                    <div class="sw-service-foot">
                        Make local problems visible
                    </div>
                </article>

                <article class="sw-service">
                    <div class="sw-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="1.7"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M3 6h11v11H3zM14 10h4l3 4v3h-7"/>
                            <circle cx="7" cy="18" r="2"/>
                            <circle cx="18" cy="18" r="2"/>
                        </svg>
                    </div>

                    <h3>Request a Collection</h3>

                    <p class="sw-copy">
                        Submit a pickup request with the relevant waste
                        details. Follow progress as collectors review
                        assigned jobs and update collection status.
                    </p>

                    <div class="sw-service-foot">
                        Stay informed from request to pickup
                    </div>
                </article>

                <article class="sw-service">
                    <div class="sw-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none"
                             stroke="currentColor" stroke-width="1.7"
                             stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 4C9 3 3 8 6 15c7 5 15-1 14-11Z"/>
                            <path d="M4 21c2-6 6-10 12-13"/>
                        </svg>
                    </div>

                    <h3>Support Recycling</h3>

                    <p class="sw-copy">
                        Connect recyclable materials with recycling
                        companies. Help useful resources move towards
                        recovery and reuse.
                    </p>

                    <div class="sw-service-foot">
                        Give useful materials another purpose
                    </div>
                </article>

            </div>
        </div>
    </section>

    <!-- PROCESS -->
    <section class="sw-section sw-process"
             id="sw-how-it-works"
             aria-labelledby="sw-process-title">
        <div class="sw-wrap">

            <div class="sw-section-top">
                <div>
                    <span class="sw-label">How it works</span>
                    <h2 id="sw-process-title">
                        From your first report<br>
                        to the next collection.
                    </h2>
                </div>

                <p class="sw-copy">
                    A clear process helps citizens and service providers
                    coordinate their next steps.
                </p>
            </div>

            <div class="sw-steps">

                <article class="sw-step">
                    <span class="sw-step-number">01 / JOIN</span>
                    <h3>Create Your Account</h3>
                    <p class="sw-copy">
                        Register for the role that matches how you will
                        use the platform.
                    </p>
                </article>

                <article class="sw-step">
                    <span class="sw-step-number">02 / REPORT</span>
                    <h3>Share the Details</h3>
                    <p class="sw-copy">
                        Describe the waste, provide its location and
                        include relevant photos.
                    </p>
                </article>

                <article class="sw-step">
                    <span class="sw-step-number">03 / COORDINATE</span>
                    <h3>Manage Collection</h3>
                    <p class="sw-copy">
                        Collectors review assigned requests and update
                        jobs as collection progresses.
                    </p>
                </article>

                <article class="sw-step">
                    <span class="sw-step-number">04 / FOLLOW UP</span>
                    <h3>Check the Outcome</h3>
                    <p class="sw-copy">
                        View status updates and collection records
                        through your dashboard.
                    </p>
                </article>

            </div>
        </div>
    </section>

    <!-- ACCOUNT ACCESS -->
    <section class="sw-section" aria-labelledby="sw-access-title">
        <div class="sw-wrap sw-access-grid">

            <div class="sw-access-copy">
                <span class="sw-label">Your community. Your contribution.</span>

                <h2 id="sw-access-title">
                    Take the next step<br>
                    towards a cleaner place.
                </h2>

                <p class="sw-copy">
                    Whether you are reporting a local issue, collecting waste
                    or recovering recyclable materials, your dashboard brings
                    your tasks together.
                </p>

                <ul class="sw-benefits">
                    <li>
                        <span class="sw-check" aria-hidden="true">✓</span>
                        <div>
                            <strong>A dashboard for your role</strong>
                            <p>
                                Access the tools relevant to your
                                responsibilities.
                            </p>
                        </div>
                    </li>

                    <li>
                        <span class="sw-check" aria-hidden="true">✓</span>
                        <div>
                            <strong>Clear progress updates</strong>
                            <p>
                                Check request status as collection
                                information is updated.
                            </p>
                        </div>
                    </li>

                    <li>
                        <span class="sw-check" aria-hidden="true">✓</span>
                        <div>
                            <strong>Connected participation</strong>
                            <p>
                                Help citizens, collectors and recyclers
                                work together.
                            </p>
                        </div>
                    </li>
                </ul>
            </div>

            <div class="sw-login" id="sw-login">
                <span class="sw-label">Account access</span>
                <h2>Welcome back.</h2>

                <p class="sw-copy">
                    Sign in to access your waste management dashboard.
                </p>

                <form action="login_action.php" method="POST">
                    <label for="sw-email">Email Address</label>
                    <input
                        type="email"
                        id="sw-email"
                        name="email"
                        placeholder="you@example.com"
                        autocomplete="username"
                        required
                    >

                    <label for="sw-password">Password</label>

                    <div class="sw-password-field">
                        <input
                            type="password"
                            id="sw-password"
                            name="password"
                            placeholder="Enter your password"
                            autocomplete="current-password"
                            required
                        >

                        <button
                            type="button"
                            class="sw-password-toggle"
                            id="sw-toggle-password"
                            aria-controls="sw-password"
                            aria-label="Show password"
                            aria-pressed="false"
                            hidden
                        >
                            Show
                        </button>
                    </div>

                    <button type="submit" class="sw-btn sw-login-submit">
                        Sign In <span aria-hidden="true">→</span>
                    </button>
                </form>

                <div class="sw-register">
                    New to the platform?
                    <a href="register.php">Create an account</a>
                </div>
            </div>

        </div>
    </section>

    <!-- USER ROLES -->
    <section class="sw-section sw-users-section"
             aria-labelledby="sw-users-title">
        <div class="sw-wrap">

            <div class="sw-section-top">
                <div>
                    <span class="sw-label">Built for collaboration</span>
                    <h2 id="sw-users-title">
                        Four roles. One shared purpose.
                    </h2>
                </div>

                <p class="sw-copy">
                    Each participant has a part to play in keeping
                    waste management organised.
                </p>
            </div>

            <div class="sw-users">

                <article class="sw-user">
                    <span class="sw-role-number">01 / COMMUNITY</span>
                    <h3>Citizen</h3>
                    <p class="sw-copy">
                        Report waste issues, upload supporting images,
                        request pickups and track collection progress.
                    </p>
                </article>

                <article class="sw-user">
                    <span class="sw-role-number">02 / COLLECTION</span>
                    <h3>Waste Collector</h3>
                    <p class="sw-copy">
                        View assigned pickups, accept jobs, add collection
                        notes and update the status of each task.
                    </p>
                </article>

                <article class="sw-user">
                    <span class="sw-role-number">03 / RECOVERY</span>
                    <h3>Recycling Company</h3>
                    <p class="sw-copy">
                        Explore recyclable waste listings, request
                        collections and maintain recycling records.
                    </p>
                </article>

                <article class="sw-user">
                    <span class="sw-role-number">04 / MANAGEMENT</span>
                    <h3>Administrator</h3>
                    <p class="sw-copy">
                        Approve accounts, manage users, review reports
                        and monitor activity across the platform.
                    </p>
                </article>

            </div>
        </div>
    </section>

    <!-- FAQ -->
    <section class="sw-section" aria-labelledby="sw-faq-title">
        <div class="sw-wrap sw-faq-grid">

            <div class="sw-faq-intro">
                <span class="sw-label">Useful to know</span>
                <h2 id="sw-faq-title">
                    Getting started,<br>
                    made clearer.
                </h2>

                <p class="sw-copy">
                    A few answers to help you understand the platform
                    before you begin.
                </p>
            </div>

            <div class="sw-faq">
                <details>
                    <summary>Who is this platform for?</summary>
                    <p class="sw-copy">
                        The platform connects citizens, waste collectors,
                        recycling companies and administrators. Each role
                        has its own responsibilities and dashboard tools.
                    </p>
                </details>

                <details>
                    <summary>What should I include in a waste report?</summary>
                    <p class="sw-copy">
                        Provide a clear description, the waste location and
                        relevant photos. Useful details help the team
                        understand the issue and plan the next steps.
                    </p>
                </details>

                <details>
                    <summary>How do I check my pickup progress?</summary>
                    <p class="sw-copy">
                        Sign in and open your pickup requests in your
                        dashboard. The status reflects the updates entered
                        as your request is managed.
                    </p>
                </details>

                <details>
                    <summary>How do recycling companies participate?</summary>
                    <p class="sw-copy">
                        Recycling companies use their dashboard to view
                        recyclable waste listings, request collections and
                        maintain records of their recycling activities.
                    </p>
                </details>

                <details>
                    <summary>What is the project's sustainability focus?</summary>
                    <p class="sw-copy">
                        The project is designed around SDG 11: Sustainable
                        Cities and Communities. Its focus is helping people
                        coordinate waste reporting, collection and material
                        recovery within their community.
                    </p>
                </details>
            </div>

        </div>
    </section>

    <!-- CLOSING CALL TO ACTION -->
    <div class="sw-wrap">
        <section class="sw-cta" aria-labelledby="sw-cta-title">
            <div>
                <h2 id="sw-cta-title">
                    A cleaner community starts with us.
                </h2>
                <p>
                    Join the platform and take part in better waste reporting,
                    collection and recycling.
                </p>
            </div>

            <a href="register.php" class="sw-btn">
                Create an Account <span aria-hidden="true">↗</span>
            </a>
        </section>
    </div>

</div>

<script>
(() => {
    "use strict";

    // Show or hide the password without submitting the form.
    const passwordInput = document.getElementById("sw-password");
    const passwordToggle = document.getElementById("sw-toggle-password");

    if (passwordInput && passwordToggle) {
        passwordToggle.hidden = false;

        passwordToggle.addEventListener("click", () => {
            const showPassword = passwordInput.type === "password";

            passwordInput.type = showPassword ? "text" : "password";
            passwordToggle.textContent = showPassword ? "Hide" : "Show";
            passwordToggle.setAttribute(
                "aria-label",
                showPassword ? "Hide password" : "Show password"
            );
            passwordToggle.setAttribute(
                "aria-pressed",
                String(showPassword)
            );
        });
    }

    // Create decorative recyclable particles inside the bottle.
    const particleContainer = document.getElementById("sw-particles");

    if (particleContainer) {
        const fragment = document.createDocumentFragment();

        for (let i = 0; i < 38; i++) {
            const particle = document.createElement("span");

            particle.className = "sw-particle";
            particle.style.left = (10 + Math.random() * 75) + "%";
            particle.style.top = (12 + Math.random() * 80) + "%";
            particle.style.setProperty(
                "--duration",
                (3 + Math.random() * 4) + "s"
            );
            particle.style.setProperty(
                "--delay",
                (-Math.random() * 7) + "s"
            );
            particle.style.setProperty(
                "--drift",
                (Math.random() * 14 - 7) + "px"
            );

            fragment.appendChild(particle);
        }

        particleContainer.appendChild(fragment);
    }

    // Move the bottle gently as the hero section scrolls.
    const bottle = document.getElementById("sw-scroll-bottle");
    const hero = document.querySelector(".sw-home .sw-hero");
    const reducedMotion = window.matchMedia(
        "(prefers-reduced-motion: reduce)"
    );

    let framePending = false;

    function updateBottle() {
        framePending = false;

        if (!bottle || !hero) {
            return;
        }

        if (reducedMotion.matches) {
            bottle.style.transform = "none";
            return;
        }

        const rect = hero.getBoundingClientRect();
        const viewportHeight = window.innerHeight;

        if (rect.bottom < 0 || rect.top > viewportHeight) {
            return;
        }

        const progress = Math.max(
            0,
            Math.min(
                1,
                (viewportHeight - rect.top) /
                (viewportHeight + rect.height)
            )
        );

        const moveY = 18 - progress * 36;
        const rotation = -8 + progress * 16;

        bottle.style.transform =
            `translateY(${moveY}px) rotate(${rotation}deg)`;
    }

    function scheduleUpdate() {
        if (!framePending) {
            framePending = true;
            window.requestAnimationFrame(updateBottle);
        }
    }

    window.addEventListener("scroll", scheduleUpdate, { passive: true });
    window.addEventListener("resize", scheduleUpdate);
    reducedMotion.addEventListener("change", scheduleUpdate);

    updateBottle();
})();
</script>

<?php require "footer.php"; ?>