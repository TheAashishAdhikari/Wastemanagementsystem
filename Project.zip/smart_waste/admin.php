<?php
require "config.php";

$user = requireRole("Admin");

$totalUsers = (int) $pdo->query(
    "SELECT COUNT(*) FROM users"
)->fetchColumn();

$totalReports = (int) $pdo->query(
    "SELECT COUNT(*) FROM waste_reports"
)->fetchColumn();

$totalPickups = (int) $pdo->query(
    "SELECT COUNT(*) FROM waste_reports
     WHERE pickup_requested = 1"
)->fetchColumn();

$totalRecycled = (int) $pdo->query(
    "SELECT COUNT(*) FROM waste_reports
     WHERE recycling_status = 'Recycled'"
)->fetchColumn();

$users = $pdo->query(
    "SELECT * FROM users ORDER BY created_at DESC"
)->fetchAll(PDO::FETCH_ASSOC);

$collectors = $pdo->query(
    "SELECT * FROM users
     WHERE role = 'Collector'
     ORDER BY created_at DESC"
)->fetchAll(PDO::FETCH_ASSOC);

$activeCollectors = $pdo->query(
    "SELECT * FROM users
     WHERE role = 'Collector'
     AND status = 'Active'
     ORDER BY name"
)->fetchAll(PDO::FETCH_ASSOC);

$reports = $pdo->query(
    "SELECT
        waste_reports.*,
        citizens.name AS citizen_name,
        collectors.name AS collector_name
     FROM waste_reports
     JOIN users AS citizens
        ON citizens.id = waste_reports.citizen_id
     LEFT JOIN users AS collectors
        ON collectors.id = waste_reports.collector_id
     ORDER BY waste_reports.created_at DESC"
)->fetchAll(PDO::FETCH_ASSOC);

$activities = $pdo->query(
    "SELECT activities.*, users.name
     FROM activities
     LEFT JOIN users ON users.id = activities.user_id
     ORDER BY activities.created_at DESC
     LIMIT 50"
)->fetchAll(PDO::FETCH_ASSOC);

$pendingCollectors = count(array_filter(
    $collectors,
    function ($collector) {
        return $collector["status"] === "Pending";
    }
));

$unassignedPickups = count(array_filter(
    $reports,
    function ($report) {
        return (int) $report["pickup_requested"] === 1
            && empty($report["collector_id"])
            && !in_array(
                $report["status"],
                ["Collected", "Completed", "Rejected"],
                true
            );
    }
));

$reportStatuses = [
    "Reported",
    "Assigned",
    "Accepted",
    "On The Way",
    "Collected",
    "Completed",
    "Rejected"
];

$activeCollectorIds = array_map(
    "intval",
    array_column($activeCollectors, "id")
);

$badgeClass = static function ($value) {
    switch ($value) {
        case "Active":
        case "Collected":
        case "Completed":
        case "Recycled":
            return "ad-badge-green";

        case "Pending":
        case "Reported":
        case "Medium":
            return "ad-badge-amber";

        case "Suspended":
        case "Rejected":
        case "High":
        case "Urgent":
            return "ad-badge-red";

        default:
            return "ad-badge-neutral";
    }
};

$pageTitle = "Admin Dashboard";
require "header.php";
?>

<style>
.ad-dashboard {
    --ad-green: #176348;
    --ad-dark: #113f31;
    --ad-lime: #d8ee97;
    --ad-ink: #172e26;
    --ad-muted: #68776d;
    --ad-line: #dfe7df;
    color: var(--ad-ink);
    font-family: Arial, Helvetica, sans-serif;
}

.ad-dashboard *,
.ad-dashboard *::before,
.ad-dashboard *::after {
    box-sizing: border-box;
}

.ad-dashboard [hidden] {
    display: none !important;
}

.ad-dashboard h1,
.ad-dashboard h2,
.ad-dashboard h3,
.ad-dashboard p {
    margin: 0;
}

.ad-dashboard a {
    text-decoration: none;
}

.ad-dashboard button,
.ad-dashboard input,
.ad-dashboard select {
    font: inherit;
}

.ad-dashboard a:focus-visible,
.ad-dashboard button:focus-visible,
.ad-dashboard input:focus-visible,
.ad-dashboard select:focus-visible,
.ad-dashboard summary:focus-visible,
.ad-dashboard .ad-table-wrap:focus-visible {
    outline: 3px solid #85aa65;
    outline-offset: 3px;
}

/* Welcome */
.ad-dashboard .ad-welcome {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 28px;
    padding: 36px;
    border-radius: 20px;
    background:
        radial-gradient(ellipse at top right, #286548, transparent 65%),
        var(--ad-dark);
    color: #fff;
}

.ad-dashboard .ad-eyebrow {
    display: block;
    margin-bottom: 13px;
    color: #6d8267;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: 1.8px;
    text-transform: uppercase;
}

.ad-dashboard .ad-welcome .ad-eyebrow {
    color: var(--ad-lime);
}

.ad-dashboard h1 {
    font-size: clamp(28px, 3.5vw, 42px);
    line-height: 1.15;
    letter-spacing: -1.5px;
}

.ad-dashboard .ad-welcome p {
    max-width: 610px;
    margin-top: 13px;
    color: #d0e0d4;
    font-size: 14px;
    line-height: 1.8;
}

.ad-dashboard .ad-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    min-height: 42px;
    padding: 11px 17px;
    border: 1px solid transparent;
    border-radius: 8px;
    background: var(--ad-green);
    color: #fff;
    font-size: 12px;
    font-weight: 700;
    line-height: 1.4;
    cursor: pointer;
}

.ad-dashboard .ad-btn:hover {
    background: var(--ad-dark);
}

.ad-dashboard .ad-btn-lime {
    flex-shrink: 0;
    background: var(--ad-lime);
    color: var(--ad-dark);
}

.ad-dashboard .ad-btn-lime:hover {
    background: #c7e77f;
}

/* Statistics */
.ad-dashboard .ad-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 17px;
    margin: 22px 0;
}

.ad-dashboard .ad-stat {
    padding: 25px;
    border: 1px solid var(--ad-line);
    border-radius: 14px;
    background: #fff;
}

.ad-dashboard .ad-stat-label {
    color: var(--ad-muted);
    font-size: 12px;
    font-weight: 700;
}

.ad-dashboard .ad-stat strong {
    display: block;
    margin: 15px 0 8px;
    color: var(--ad-dark);
    font-size: 36px;
    line-height: 1;
    letter-spacing: -1.5px;
}

.ad-dashboard .ad-stat p {
    color: var(--ad-muted);
    font-size: 11px;
    line-height: 1.7;
}

/* Navigation and workload */
.ad-dashboard .ad-section-nav {
    display: flex;
    flex-wrap: wrap;
    gap: 9px;
    margin: 25px 0;
}

.ad-dashboard .ad-section-nav a {
    padding: 11px 15px;
    border: 1px solid var(--ad-line);
    border-radius: 8px;
    background: #fff;
    color: #405f49;
    font-size: 12px;
    font-weight: 700;
}

.ad-dashboard .ad-section-nav a:hover {
    background: #eaf0e4;
}

.ad-dashboard .ad-workload {
    display: flex;
    flex-wrap: wrap;
    gap: 12px 25px;
    margin-bottom: 25px;
    padding: 17px 20px;
    border: 1px solid #dae4ce;
    border-radius: 11px;
    background: #edf3e4;
    color: #46613b;
    font-size: 13px;
    line-height: 1.6;
}

.ad-dashboard .ad-workload strong {
    color: var(--ad-dark);
}

/* Panels */
.ad-dashboard .ad-panel {
    margin-bottom: 25px;
    border: 1px solid var(--ad-line);
    border-radius: 16px;
    background: #fff;
    scroll-margin-top: 110px;
    overflow: hidden;
}

.ad-dashboard .ad-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 25px;
    border-bottom: 1px solid var(--ad-line);
}

.ad-dashboard h2 {
    font-size: 21px;
    line-height: 1.3;
    letter-spacing: -.6px;
}

.ad-dashboard .ad-panel-head p {
    margin-top: 7px;
    color: var(--ad-muted);
    font-size: 12px;
    line-height: 1.7;
}

.ad-dashboard .ad-count {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 32px;
    padding: 7px 10px;
    border-radius: 8px;
    background: #edf2e7;
    color: var(--ad-green);
    font-size: 12px;
    font-weight: 700;
}

.ad-dashboard .ad-tools {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 14px;
    padding: 18px 25px;
    border-bottom: 1px solid var(--ad-line);
    background: #fafbf8;
}

.ad-dashboard .ad-field {
    min-width: 0;
}

.ad-dashboard .ad-search-field {
    flex: 1 1 240px;
}

.ad-dashboard .ad-field label,
.ad-dashboard .ad-inline-form label {
    display: block;
    margin-bottom: 7px;
    color: #53695b;
    font-size: 11px;
    font-weight: 700;
}

.ad-dashboard input[type="search"],
.ad-dashboard select {
    width: 100%;
    min-height: 42px;
    margin: 0;
    padding: 10px 12px;
    border: 1px solid #d6e0d3;
    border-radius: 7px;
    background: #fff;
    color: var(--ad-ink);
    font-size: 12px;
}

.ad-dashboard .ad-result-count {
    margin-left: auto;
    padding-bottom: 12px;
    color: var(--ad-muted);
    font-size: 12px;
}

/* Tables */
.ad-dashboard .ad-table-wrap {
    overflow-x: auto;
}

.ad-dashboard table {
    width: 100%;
    margin: 0;
    border-collapse: collapse;
    text-align: left;
    font-size: 12px;
}

.ad-dashboard th {
    padding: 15px 23px;
    border: 0;
    border-bottom: 1px solid var(--ad-line);
    background: #f5f8f0;
    color: #61705f;
    font-size: 10px;
    letter-spacing: .7px;
    text-transform: uppercase;
    white-space: nowrap;
}

.ad-dashboard td {
    padding: 18px 23px;
    border: 0;
    border-bottom: 1px solid #edf0e9;
    background: #fff;
    color: #43574a;
    line-height: 1.7;
    vertical-align: middle;
}

.ad-dashboard tbody tr:last-child td {
    border-bottom: 0;
}

.ad-dashboard tbody tr:hover td {
    background: #fcfdf9;
}

.ad-dashboard .ad-person {
    color: var(--ad-ink);
    font-weight: 700;
}

.ad-dashboard .ad-subtext {
    display: block;
    margin-top: 4px;
    color: var(--ad-muted);
    font-size: 11px;
}

.ad-dashboard .ad-inline-form {
    display: flex;
    align-items: flex-end;
    gap: 8px;
    margin: 0;
}

.ad-dashboard .ad-inline-form select {
    min-width: 125px;
}

.ad-dashboard .ad-inline-form .ad-btn {
    flex-shrink: 0;
}

.ad-dashboard .ad-badge {
    display: inline-flex;
    align-items: center;
    padding: 5px 9px;
    border-radius: 6px;
    font-size: 10px;
    font-weight: 700;
    line-height: 1.6;
    white-space: nowrap;
}

.ad-dashboard .ad-badge-green {
    background: #e8f3e9;
    color: #27683c;
}

.ad-dashboard .ad-badge-amber {
    background: #fff2d8;
    color: #825911;
}

.ad-dashboard .ad-badge-red {
    background: #fbe9e5;
    color: #9a4032;
}

.ad-dashboard .ad-badge-neutral {
    background: #edf1f4;
    color: #506575;
}

/* Waste report cards */
.ad-dashboard .ad-report-list {
    display: grid;
    gap: 15px;
    padding: 23px;
}

.ad-dashboard .ad-report {
    border: 1px solid var(--ad-line);
    border-radius: 11px;
    overflow: hidden;
}

.ad-dashboard .ad-report summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    padding: 21px;
    cursor: pointer;
    list-style: none;
}

.ad-dashboard .ad-report summary::-webkit-details-marker {
    display: none;
}

.ad-dashboard .ad-report summary::after {
    content: "+";
    flex-shrink: 0;
    color: var(--ad-green);
    font-size: 23px;
}

.ad-dashboard .ad-report[open] summary::after {
    content: "−";
}

.ad-dashboard .ad-report-title {
    display: block;
    color: var(--ad-ink);
    font-size: 14px;
    font-weight: 700;
    overflow-wrap: anywhere;
}

.ad-dashboard .ad-report-id {
    margin-right: 6px;
    color: #7e8d75;
}

.ad-dashboard .ad-report-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 7px;
    margin: 10px 0;
}

.ad-dashboard .ad-report form {
    margin: 0;
    padding: 22px;
    border-top: 1px solid var(--ad-line);
    background: #fafbf8;
}

.ad-dashboard .ad-report-fields {
    display: grid;
    grid-template-columns: 1.3fr 1fr 1fr;
    gap: 15px;
}

.ad-dashboard .ad-report-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    margin-top: 21px;
}

.ad-dashboard .ad-checkbox {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    color: #4c6554;
    font-size: 12px;
    cursor: pointer;
}

.ad-dashboard .ad-checkbox input {
    width: 17px;
    height: 17px;
    margin: 0;
    accent-color: var(--ad-green);
}

.ad-dashboard .ad-empty {
    padding: 30px;
    color: var(--ad-muted);
    font-size: 13px;
    line-height: 1.8;
    text-align: center;
}

.ad-dashboard .ad-date {
    white-space: nowrap;
    font-size: 11px;
}

@media (max-width: 950px) {
    .ad-dashboard .ad-stats {
        grid-template-columns: repeat(2, 1fr);
    }

    .ad-dashboard .ad-report-fields {
        grid-template-columns: 1fr 1fr;
    }

    .ad-dashboard .ad-report-fields .ad-field:first-child {
        grid-column: 1 / -1;
    }
}

@media (max-width: 600px) {
    .ad-dashboard .ad-welcome {
        align-items: flex-start;
        flex-direction: column;
        padding: 26px;
    }

    .ad-dashboard .ad-stats {
        gap: 10px;
    }

    .ad-dashboard .ad-stat {
        padding: 19px;
    }

    .ad-dashboard .ad-stat strong {
        font-size: 30px;
    }

    .ad-dashboard .ad-panel-head {
        padding: 20px;
    }

    .ad-dashboard .ad-tools {
        padding: 17px 20px;
    }

    .ad-dashboard .ad-tools .ad-field {
        width: 100%;
    }

    .ad-dashboard .ad-result-count {
        margin-left: 0;
        padding-bottom: 0;
    }

    .ad-dashboard .ad-report-list {
        padding: 14px;
    }

    .ad-dashboard .ad-report-fields {
        grid-template-columns: 1fr;
    }

    .ad-dashboard .ad-report-footer {
        align-items: stretch;
        flex-direction: column;
    }

    .ad-dashboard .ad-section-nav a {
        flex: 1 1 40%;
        text-align: center;
    }
}
</style>

<div class="ad-dashboard">

    <!-- Welcome -->
    <section class="ad-welcome" aria-labelledby="ad-title">
        <div>
            <span class="ad-eyebrow">Administration / Overview</span>

            <h1 id="ad-title">A clearer view of your community.</h1>

            <p>
                Welcome back, <?php echo clean($user["name"]); ?>.
                Review accounts, coordinate collections and keep track
                of waste management activity.
            </p>
        </div>

        <a href="export_report.php" class="ad-btn ad-btn-lime">
            Export CSV <span aria-hidden="true">↓</span>
        </a>
    </section>

    <!-- Database totals -->
    <div class="ad-stats">
        <article class="ad-stat">
            <span class="ad-stat-label">Total Users</span>
            <strong><?php echo number_format($totalUsers); ?></strong>
            <p>Registered accounts across all roles</p>
        </article>

        <article class="ad-stat">
            <span class="ad-stat-label">Waste Reports</span>
            <strong><?php echo number_format($totalReports); ?></strong>
            <p>All submitted waste reports</p>
        </article>

        <article class="ad-stat">
            <span class="ad-stat-label">Pickup Requests</span>
            <strong><?php echo number_format($totalPickups); ?></strong>
            <p>Reports with a pickup requested</p>
        </article>

        <article class="ad-stat">
            <span class="ad-stat-label">Recycled Records</span>
            <strong><?php echo number_format($totalRecycled); ?></strong>
            <p>Reports marked as recycled</p>
        </article>
    </div>

    <nav class="ad-section-nav" aria-label="Dashboard sections">
        <a href="#ad-collectors">Collector Accounts</a>
        <a href="#ad-users">Manage Users</a>
        <a href="#ad-reports">Waste Reports</a>
        <a href="#ad-activities">Activity Log</a>
    </nav>

    <div class="ad-workload">
        <span>
            <strong><?php echo $pendingCollectors; ?></strong>
            pending collector accounts
        </span>

        <span>
            <strong><?php echo $unassignedPickups; ?></strong>
            open pickup requests without a collector
        </span>

        <span>
            <strong><?php echo count($activeCollectors); ?></strong>
            active collector accounts
        </span>
    </div>

    <!-- Collectors -->
    <section class="ad-panel" id="ad-collectors">
        <div class="ad-panel-head">
            <div>
                <h2>Collector Accounts</h2>
                <p>Review account status and approve or suspend collectors.</p>
            </div>

            <span class="ad-count"><?php echo count($collectors); ?></span>
        </div>

        <div class="ad-table-wrap" tabindex="0"
             role="region" aria-label="Collector accounts table">
            <table>
                <thead>
                    <tr>
                        <th scope="col">Collector</th>
                        <th scope="col">Status</th>
                        <th scope="col">Availability</th>
                        <th scope="col">Account Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($collectors as $collector): ?>
                        <tr>
                            <td>
                                <span class="ad-person">
                                    <?php echo clean($collector["name"]); ?>
                                </span>
                                <span class="ad-subtext">
                                    <?php echo clean($collector["email"]); ?>
                                </span>
                            </td>

                            <td>
                                <span class="ad-badge <?php
                                    echo $badgeClass($collector["status"]);
                                ?>">
                                    <?php echo clean($collector["status"]); ?>
                                </span>
                            </td>

                            <td>
                                <?php echo clean(
                                    $collector["availability"] ?? "Not specified"
                                ); ?>
                            </td>

                            <td>
                                <form action="admin_action.php"
                                      method="POST"
                                      class="ad-inline-form">
                                    <input type="hidden" name="action"
                                           value="approve_collector">
                                    <input type="hidden" name="user_id"
                                           value="<?php echo (int) $collector["id"]; ?>">

                                    <div>
                                        <label for="ad-collector-<?php
                                            echo (int) $collector["id"];
                                        ?>">Account decision</label>

                                        <select name="status" required
                                                id="ad-collector-<?php
                                                    echo (int) $collector["id"];
                                                ?>">
                                            <option value="" disabled selected>
                                                Choose action
                                            </option>
                                            <option value="Active">Approve</option>
                                            <option value="Suspended">Suspend</option>
                                        </select>
                                    </div>

                                    <button type="submit" class="ad-btn">
                                        Save
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <?php if (!$collectors): ?>
                        <tr>
                            <td colspan="4" class="ad-empty">
                                No collector accounts have been registered yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- Users -->
    <section class="ad-panel" id="ad-users">
        <div class="ad-panel-head">
            <div>
                <h2>Manage Users</h2>
                <p>Search accounts and manage access to the platform.</p>
            </div>

            <span class="ad-count"><?php echo count($users); ?></span>
        </div>

        <div class="ad-tools" id="ad-user-tools" hidden>
            <div class="ad-field ad-search-field">
                <label for="ad-user-search">Search users</label>
                <input type="search" id="ad-user-search"
                       placeholder="Search by name or email">
            </div>

            <div class="ad-field">
                <label for="ad-role-filter">Role</label>
                <select id="ad-role-filter">
                    <option value="">All roles</option>
                    <option value="Citizen">Citizen</option>
                    <option value="Collector">Collector</option>
                    <option value="Recycler">Recycler</option>
                    <option value="Admin">Admin</option>
                </select>
            </div>

            <span class="ad-result-count" id="ad-user-count"
                  role="status"></span>
        </div>

        <div class="ad-table-wrap" tabindex="0"
             role="region" aria-label="User accounts table">
            <table>
                <thead>
                    <tr>
                        <th scope="col">User</th>
                        <th scope="col">Role</th>
                        <th scope="col">Status</th>
                        <th scope="col">Manage Access</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($users as $account): ?>
                        <tr class="ad-user-row"
                            data-search="<?php echo clean(
                                $account["name"] . " " . $account["email"]
                            ); ?>"
                            data-role="<?php echo clean($account["role"]); ?>">

                            <td>
                                <span class="ad-person">
                                    <?php echo clean($account["name"]); ?>
                                </span>
                                <span class="ad-subtext">
                                    <?php echo clean($account["email"]); ?>
                                </span>
                            </td>

                            <td><?php echo clean($account["role"]); ?></td>

                            <td>
                                <span class="ad-badge <?php
                                    echo $badgeClass($account["status"]);
                                ?>">
                                    <?php echo clean($account["status"]); ?>
                                </span>
                            </td>

                            <td>
                                <?php if ($account["id"] != $user["id"]): ?>
                                    <form action="admin_action.php"
                                          method="POST"
                                          class="ad-inline-form">
                                        <input type="hidden" name="action"
                                               value="user_status">
                                        <input type="hidden" name="user_id"
                                               value="<?php echo (int) $account["id"]; ?>">

                                        <div>
                                            <label for="ad-user-status-<?php
                                                echo (int) $account["id"];
                                            ?>">Account status</label>

                                            <select name="status"
                                                    id="ad-user-status-<?php
                                                        echo (int) $account["id"];
                                                    ?>">
                                                <?php foreach (
                                                    ["Active", "Pending", "Suspended"]
                                                    as $status
                                                ): ?>
                                                    <option value="<?php echo clean($status); ?>"
                                                        <?php echo $account["status"] === $status
                                                            ? "selected" : ""; ?>>
                                                        <?php echo clean($status); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>

                                        <button type="submit" class="ad-btn">
                                            Update
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="ad-badge ad-badge-neutral">
                                        Your account
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <tr id="ad-users-empty" <?php echo $users ? "hidden" : ""; ?>>
                        <td colspan="4" class="ad-empty">
                            No users match your search.
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>

    <!-- Reports -->
    <section class="ad-panel" id="ad-reports">
        <div class="ad-panel-head">
            <div>
                <h2>Manage Waste Reports</h2>
                <p>Open a report to assign a collector, set priority or update progress.</p>
            </div>

            <span class="ad-count"><?php echo count($reports); ?></span>
        </div>

        <div class="ad-tools" id="ad-report-tools" hidden>
            <div class="ad-field ad-search-field">
                <label for="ad-report-search">Search reports</label>
                <input type="search" id="ad-report-search"
                       placeholder="Search ID, title, location or citizen">
            </div>

            <div class="ad-field">
                <label for="ad-report-filter">Report status</label>
                <select id="ad-report-filter">
                    <option value="">All statuses</option>
                    <?php foreach ($reportStatuses as $status): ?>
                        <option value="<?php echo clean($status); ?>">
                            <?php echo clean($status); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <span class="ad-result-count" id="ad-report-count"
                  role="status"></span>
        </div>

        <div class="ad-report-list">
            <?php foreach ($reports as $report): ?>
                <?php $reportId = (int) $report["id"]; ?>

                <details class="ad-report"
                         data-search="<?php echo clean(
                             $reportId . " " .
                             $report["title"] . " " .
                             $report["location"] . " " .
                             $report["citizen_name"]
                         ); ?>"
                         data-status="<?php echo clean($report["status"]); ?>">

                    <summary>
                        <span>
                            <span class="ad-report-title">
                                <span class="ad-report-id">
                                    #<?php echo $reportId; ?>
                                </span>
                                <?php echo clean($report["title"]); ?>
                            </span>

                            <span class="ad-report-tags">
                                <span class="ad-badge <?php
                                    echo $badgeClass($report["status"]);
                                ?>">
                                    <?php echo clean($report["status"]); ?>
                                </span>

                                <span class="ad-badge <?php
                                    echo $badgeClass($report["priority"]);
                                ?>">
                                    <?php echo clean($report["priority"]); ?> priority
                                </span>

                                <?php if ((int) $report["recyclable"] === 1): ?>
                                    <span class="ad-badge ad-badge-green">
                                        Recyclable
                                    </span>
                                <?php endif; ?>
                            </span>

                            <span class="ad-subtext">
                                <?php echo clean($report["citizen_name"]); ?>
                                · <?php echo clean($report["location"]); ?>
                            </span>

                            <span class="ad-subtext">
                                Collector:
                                <?php echo clean(
                                    $report["collector_name"] ?? "Not assigned"
                                ); ?>
                            </span>
                        </span>
                    </summary>

                    <form action="admin_action.php" method="POST">
                        <input type="hidden" name="action" value="report">
                        <input type="hidden" name="report_id"
                               value="<?php echo $reportId; ?>">

                        <div class="ad-report-fields">
                            <div class="ad-field">
                                <label for="ad-assign-<?php echo $reportId; ?>">
                                    Assign Collector
                                </label>

                                <select name="collector_id"
                                        id="ad-assign-<?php echo $reportId; ?>">
                                    <option value="0"
                                        <?php echo empty($report["collector_id"])
                                            ? "selected" : ""; ?>>
                                        Not Assigned
                                    </option>

                                    <?php
                                    // Preserve an existing assignment if the
                                    // collector is no longer in the active list.
                                    if (
                                        !empty($report["collector_id"]) &&
                                        !in_array(
                                            (int) $report["collector_id"],
                                            $activeCollectorIds,
                                            true
                                        )
                                    ):
                                    ?>
                                        <option
                                            value="<?php echo (int) $report["collector_id"]; ?>"
                                            selected>
                                            <?php echo clean(
                                                $report["collector_name"] ?? "Current collector"
                                            ); ?> — Current assignment (not active)
                                        </option>
                                    <?php endif; ?>

                                    <?php foreach ($activeCollectors as $collector): ?>
                                        <option
                                            value="<?php echo (int) $collector["id"]; ?>"
                                            <?php echo $report["collector_id"] == $collector["id"]
                                                ? "selected" : ""; ?>>
                                            <?php echo clean($collector["name"]); ?>
                                            — <?php echo clean(
                                                $collector["availability"] ?? "Not specified"
                                            ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="ad-field">
                                <label for="ad-status-<?php echo $reportId; ?>">
                                    Report Status
                                </label>

                                <select name="status"
                                        id="ad-status-<?php echo $reportId; ?>">
                                    <?php foreach ($reportStatuses as $status): ?>
                                        <option value="<?php echo clean($status); ?>"
                                            <?php echo $report["status"] === $status
                                                ? "selected" : ""; ?>>
                                            <?php echo clean($status); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="ad-field">
                                <label for="ad-priority-<?php echo $reportId; ?>">
                                    Priority
                                </label>

                                <select name="priority"
                                        id="ad-priority-<?php echo $reportId; ?>">
                                    <?php foreach (
                                        ["Low", "Medium", "High", "Urgent"]
                                        as $priority
                                    ): ?>
                                        <option value="<?php echo clean($priority); ?>"
                                            <?php echo $report["priority"] === $priority
                                                ? "selected" : ""; ?>>
                                            <?php echo clean($priority); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>

                        <div class="ad-report-footer">
                            <label class="ad-checkbox"
                                   for="ad-recyclable-<?php echo $reportId; ?>">
                                <input
                                    type="checkbox"
                                    id="ad-recyclable-<?php echo $reportId; ?>"
                                    name="recyclable"
                                    value="1"
                                    <?php echo (int) $report["recyclable"] === 1
                                        ? "checked" : ""; ?>
                                >
                                Recyclable Waste
                            </label>

                            <button type="submit" class="ad-btn">
                                Save Report Changes
                            </button>
                        </div>
                    </form>
                </details>
            <?php endforeach; ?>

            <p class="ad-empty" id="ad-reports-empty"
               <?php echo $reports ? "hidden" : ""; ?>>
                No waste reports to display.
            </p>
        </div>
    </section>

    <!-- Activities -->
    <section class="ad-panel" id="ad-activities">
        <div class="ad-panel-head">
            <div>
                <h2>System Activity</h2>
                <p>The latest 50 recorded activities, with the newest first.</p>
            </div>

            <span class="ad-count"><?php echo count($activities); ?></span>
        </div>

        <div class="ad-table-wrap" tabindex="0"
             role="region" aria-label="System activity table">
            <table>
                <thead>
                    <tr>
                        <th scope="col">User</th>
                        <th scope="col">Activity</th>
                        <th scope="col">Recorded At</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($activities as $activity): ?>
                        <tr>
                            <td class="ad-person">
                                <?php echo clean($activity["name"] ?? "System"); ?>
                            </td>

                            <td>
                                <?php echo clean($activity["activity"]); ?>
                            </td>

                            <td class="ad-date">
                                <?php echo clean($activity["created_at"]); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <?php if (!$activities): ?>
                        <tr>
                            <td colspan="3" class="ad-empty">
                                No system activities have been recorded yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>

<script>
(() => {
    "use strict";

    function setupFilter(settings) {
        const search = document.getElementById(settings.searchId);
        const filter = document.getElementById(settings.filterId);
        const counter = document.getElementById(settings.counterId);
        const empty = document.getElementById(settings.emptyId);
        const toolbar = document.getElementById(settings.toolbarId);
        const items = Array.from(
            document.querySelectorAll(settings.itemSelector)
        );

        if (!search || !filter || !counter || !empty || !toolbar) {
            return;
        }

        function applyFilter() {
            const query = search.value.trim().toLocaleLowerCase();
            const selectedValue = filter.value;
            let visible = 0;

            items.forEach((item) => {
                const text = (item.dataset.search || "").toLocaleLowerCase();
                const matchesText = text.includes(query);
                const matchesFilter = !selectedValue ||
                    item.dataset[settings.filterKey] === selectedValue;

                const show = matchesText && matchesFilter;

                item.hidden = !show;

                if (show) {
                    visible++;
                }
            });

            empty.hidden = visible !== 0;
            counter.textContent = `${visible} of ${items.length} shown`;
        }

        toolbar.hidden = false;
        search.addEventListener("input", applyFilter);
        filter.addEventListener("change", applyFilter);

        applyFilter();
    }

    setupFilter({
        searchId: "ad-user-search",
        filterId: "ad-role-filter",
        counterId: "ad-user-count",
        emptyId: "ad-users-empty",
        toolbarId: "ad-user-tools",
        itemSelector: ".ad-user-row",
        filterKey: "role"
    });

    setupFilter({
        searchId: "ad-report-search",
        filterId: "ad-report-filter",
        counterId: "ad-report-count",
        emptyId: "ad-reports-empty",
        toolbarId: "ad-report-tools",
        itemSelector: ".ad-report",
        filterKey: "status"
    });
})();
</script>

<?php require "footer.php"; ?>