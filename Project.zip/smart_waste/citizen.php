<?php
require "config.php";

$user = requireRole("Citizen");

$stmt = $pdo->prepare(
    "SELECT
        waste_reports.*,
        collectors.name AS collector_name
     FROM waste_reports
     LEFT JOIN users AS collectors
        ON collectors.id = waste_reports.collector_id
     WHERE waste_reports.citizen_id = ?
     ORDER BY waste_reports.created_at DESC"
);

$stmt->execute([$user["id"]]);
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalReports = count($reports);
$totalPickups = 0;
$totalCompleted = 0;
$totalRecycled = 0;

foreach ($reports as $report) {
    if ((int) $report["pickup_requested"] === 1) {
        $totalPickups++;
    }

    if ($report["status"] === "Completed") {
        $totalCompleted++;
    }

    if ($report["recycling_status"] === "Recycled") {
        $totalRecycled++;
    }
}

$statusClass = static function ($status) {
    switch ($status) {
        case "Completed":
        case "Collected":
        case "Recycled":
            return "ct-badge-green";

        case "Reported":
        case "Pending":
            return "ct-badge-amber";

        case "Rejected":
            return "ct-badge-red";

        default:
            return "ct-badge-blue";
    }
};

$historyStatuses = array_unique(array_column($reports, "status"));
sort($historyStatuses);

$pageTitle = "Citizen Dashboard";
require "header.php";
?>

<style>
.ct-page {
    --ct-green: #176348;
    --ct-dark: #113f31;
    --ct-lime: #d8ee97;
    --ct-text: #20382b;
    --ct-muted: #526457;
    --ct-line: #dce5d7;

    color: var(--ct-text);
    font-family: Arial, Helvetica, sans-serif;
    font-size: 16px;
    line-height: 1.6;
}

.ct-page *,
.ct-page *::before,
.ct-page *::after {
    box-sizing: border-box;
}

.ct-page [hidden] {
    display: none !important;
}

.ct-page h1,
.ct-page h2,
.ct-page h3,
.ct-page p {
    margin: 0;
}

.ct-page button,
.ct-page input,
.ct-page select,
.ct-page textarea {
    font: inherit;
}

.ct-page a:focus-visible,
.ct-page button:focus-visible,
.ct-page input:focus-visible,
.ct-page select:focus-visible,
.ct-page textarea:focus-visible,
.ct-page .ct-table-wrap:focus-visible {
    outline: 3px solid #7ba15f;
    outline-offset: 3px;
}

/* Welcome */
.ct-page .ct-welcome {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 25px;
    padding: 35px;
    border-radius: 20px;
    background:
        radial-gradient(ellipse at top right, #2c694c, transparent 65%),
        var(--ct-dark);
    color: #fff;
}

.ct-page .ct-eyebrow {
    display: block;
    margin-bottom: 12px;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
}

.ct-page .ct-welcome .ct-eyebrow {
    color: var(--ct-lime);
}

.ct-page h1 {
    font-size: clamp(29px, 3.5vw, 42px);
    line-height: 1.2;
    letter-spacing: -.7px;
    overflow-wrap: anywhere;
}

.ct-page .ct-welcome p {
    max-width: 650px;
    margin-top: 14px;
    color: #e0ece2;
    font-size: 16px;
    line-height: 1.8;
}

.ct-page .ct-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    min-height: 49px;
    padding: 12px 20px;
    border: 1px solid transparent;
    border-radius: 9px;
    background: var(--ct-green);
    color: #fff;
    font-size: 16px;
    font-weight: 700;
    line-height: 1.5;
    text-decoration: none;
    cursor: pointer;
}

.ct-page .ct-btn:hover {
    background: var(--ct-dark);
}

.ct-page .ct-btn-lime {
    flex-shrink: 0;
    background: var(--ct-lime);
    color: var(--ct-dark);
}

.ct-page .ct-btn-lime:hover {
    background: #c7e77f;
}

.ct-page .ct-btn-full {
    width: 100%;
}

/* Statistics */
.ct-page .ct-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin: 23px 0;
}

.ct-page .ct-stat {
    padding: 24px;
    border: 1px solid var(--ct-line);
    border-radius: 14px;
    background: #fff;
}

.ct-page .ct-stat-label {
    color: #3c5544;
    font-size: 15px;
    font-weight: 700;
}

.ct-page .ct-stat strong {
    display: block;
    margin: 13px 0 8px;
    color: var(--ct-dark);
    font-size: 38px;
    line-height: 1;
    letter-spacing: -1px;
}

.ct-page .ct-stat p {
    color: var(--ct-muted);
    font-size: 14px;
    line-height: 1.7;
}

/* Main layout */
.ct-page .ct-layout {
    display: grid;
    grid-template-columns: 1.35fr 1fr;
    align-items: start;
    gap: 23px;
    margin: 25px 0;
}

.ct-page .ct-sidebar {
    display: grid;
    gap: 23px;
    min-width: 0;
}

.ct-page .ct-panel {
    min-width: 0;
    border: 1px solid var(--ct-line);
    border-radius: 16px;
    background: #fff;
    overflow: hidden;
    scroll-margin-top: 110px;
}

.ct-page .ct-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 18px;
    padding: 25px;
    border-bottom: 1px solid var(--ct-line);
}

.ct-page h2 {
    font-size: 25px;
    line-height: 1.3;
    letter-spacing: -.4px;
}

.ct-page .ct-panel-head p {
    margin-top: 9px;
    color: var(--ct-muted);
    font-size: 15px;
    line-height: 1.75;
}

.ct-page .ct-panel-body {
    padding: 25px;
}

.ct-page .ct-count {
    display: grid;
    place-items: center;
    min-width: 36px;
    min-height: 36px;
    padding: 5px 10px;
    border-radius: 9px;
    background: #edf3e5;
    color: var(--ct-green);
    font-size: 15px;
    font-weight: 700;
}

/* Forms */
.ct-page form {
    margin: 0;
}

.ct-page .ct-form-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 21px 17px;
}

.ct-page .ct-field {
    min-width: 0;
}

.ct-page .ct-full {
    grid-column: 1 / -1;
}

.ct-page .ct-field label {
    display: block;
    margin-bottom: 8px;
    color: #304c39;
    font-size: 15px;
    font-weight: 700;
}

.ct-page .ct-required {
    color: #9b3e2c;
}

.ct-page .ct-optional {
    color: var(--ct-muted);
    font-size: 14px;
    font-weight: 400;
}

.ct-page .ct-field input,
.ct-page .ct-field select,
.ct-page .ct-field textarea {
    display: block;
    width: 100%;
    min-height: 50px;
    margin: 0;
    padding: 12px 14px;
    border: 1px solid #cddac8;
    border-radius: 9px;
    background: #fcfdf9;
    color: var(--ct-text);
    font-size: 16px;
    line-height: 1.5;
}

.ct-page .ct-field textarea {
    min-height: 130px;
    resize: vertical;
}

.ct-page .ct-field input::placeholder,
.ct-page .ct-field textarea::placeholder {
    color: #657269;
    opacity: 1;
}

.ct-page .ct-field input:focus,
.ct-page .ct-field select:focus,
.ct-page .ct-field textarea:focus {
    border-color: var(--ct-green);
    background: #fff;
}

.ct-page .ct-help {
    margin-top: 8px;
    color: var(--ct-muted);
    font-size: 14px;
    line-height: 1.7;
}

.ct-page .ct-required-note {
    margin-bottom: 21px;
    color: var(--ct-muted);
    font-size: 14px;
}

.ct-page .ct-upload {
    padding: 18px;
    border: 1px dashed #9fb790;
    border-radius: 10px;
    background: #f4f8ed;
}

.ct-page .ct-upload input[type="file"] {
    min-height: auto;
    padding: 0;
    border: 0;
    border-radius: 0;
    background: transparent;
    font-size: 14px;
}

.ct-page .ct-upload input::file-selector-button {
    margin-right: 12px;
    padding: 10px 12px;
    border: 1px solid #c5d5bb;
    border-radius: 6px;
    background: #fff;
    color: var(--ct-dark);
    font: inherit;
    font-weight: 700;
    cursor: pointer;
}

.ct-page .ct-preview {
    margin: 15px 0 0;
}

.ct-page .ct-preview img {
    display: block;
    width: 100%;
    max-height: 240px;
    border: 1px solid var(--ct-line);
    border-radius: 9px;
    background: #fff;
    object-fit: contain;
}

.ct-page .ct-preview figcaption {
    margin-top: 7px;
    color: var(--ct-muted);
    font-size: 14px;
}

.ct-page .ct-options {
    display: grid;
    gap: 12px;
    margin: 24px 0;
}

.ct-page .ct-checkbox {
    display: flex;
    align-items: flex-start;
    gap: 11px;
    padding: 14px;
    border: 1px solid var(--ct-line);
    border-radius: 9px;
    background: #fafcf6;
    cursor: pointer;
}

.ct-page .ct-checkbox input {
    flex: 0 0 19px;
    width: 19px;
    height: 19px;
    margin: 4px 0 0;
    accent-color: var(--ct-green);
}

.ct-page .ct-checkbox strong {
    display: block;
    font-size: 15px;
}

.ct-page .ct-checkbox span span {
    display: block;
    margin-top: 4px;
    color: var(--ct-muted);
    font-size: 14px;
    line-height: 1.7;
}

.ct-page .ct-profile-grid {
    display: grid;
    gap: 20px;
    margin-bottom: 23px;
}

/* Guidance */
.ct-page .ct-guide {
    padding: 25px;
    border: 1px solid #d6e2ca;
    border-radius: 15px;
    background: #edf4e3;
}

.ct-page .ct-guide h3 {
    color: var(--ct-dark);
    font-size: 21px;
}

.ct-page .ct-guide ul {
    display: grid;
    gap: 12px;
    margin: 18px 0 0;
    padding-left: 20px;
    color: #40583b;
    font-size: 15px;
    line-height: 1.8;
}

/* History filters */
.ct-page .ct-tools {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 15px;
    padding: 20px 25px;
    border-bottom: 1px solid var(--ct-line);
    background: #fafcf6;
}

.ct-page .ct-search {
    flex: 1 1 270px;
}

.ct-page .ct-results {
    padding-bottom: 12px;
    color: var(--ct-muted);
    font-size: 14px;
}

/* History table */
.ct-page .ct-table-wrap {
    overflow-x: auto;
}

.ct-page table {
    width: 100%;
    margin: 0;
    border-collapse: collapse;
    font-size: 15px;
    text-align: left;
}

.ct-page th {
    padding: 16px 20px;
    border: 0;
    border-bottom: 1px solid var(--ct-line);
    background: #f1f6e9;
    color: #35503b;
    font-size: 14px;
    font-weight: 700;
    white-space: nowrap;
}

.ct-page td {
    padding: 18px 20px;
    border: 0;
    border-bottom: 1px solid #e9eee4;
    background: #fff;
    color: #334c3b;
    font-size: 15px;
    line-height: 1.7;
    vertical-align: middle;
}

.ct-page tbody tr:last-child td {
    border-bottom: 0;
}

.ct-page .ct-waste-cell {
    display: flex;
    align-items: center;
    gap: 13px;
    min-width: 230px;
}

.ct-page .ct-thumbnail {
    display: block;
    flex: 0 0 60px;
    width: 60px;
    height: 60px;
    border: 1px solid var(--ct-line);
    border-radius: 10px;
    object-fit: cover;
}

.ct-page .ct-no-image {
    display: grid;
    place-items: center;
    background: #eff4e8;
    color: #526747;
    font-size: 11px;
    text-align: center;
}

.ct-page .ct-subtext {
    display: block;
    margin-top: 4px;
    color: var(--ct-muted);
    font-size: 14px;
}

.ct-page .ct-badge {
    display: inline-flex;
    padding: 6px 10px;
    border-radius: 7px;
    font-size: 13px;
    font-weight: 700;
    line-height: 1.5;
    white-space: nowrap;
}

.ct-page .ct-badge-green {
    background: #e5f2e7;
    color: #27653b;
}

.ct-page .ct-badge-amber {
    background: #fff1d5;
    color: #805710;
}

.ct-page .ct-badge-red {
    background: #fbe8e3;
    color: #943c30;
}

.ct-page .ct-badge-blue {
    background: #eaf0f5;
    color: #365a72;
}

.ct-page .ct-empty {
    padding: 38px 25px;
    color: var(--ct-muted);
    font-size: 16px;
    line-height: 1.8;
    text-align: center;
}

@media (max-width: 1000px) {
    .ct-page .ct-stats {
        grid-template-columns: repeat(2, 1fr);
    }

    .ct-page .ct-layout {
        grid-template-columns: 1.15fr 1fr;
    }

    .ct-page .ct-form-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 800px) {
    .ct-page .ct-layout {
        grid-template-columns: 1fr;
    }

    .ct-page .ct-welcome {
        align-items: flex-start;
        flex-direction: column;
    }
}

@media (max-width: 520px) {
    .ct-page .ct-welcome {
        padding: 26px;
    }

    .ct-page .ct-stats {
        gap: 10px;
    }

    .ct-page .ct-stat {
        padding: 18px;
    }

    .ct-page .ct-stat strong {
        font-size: 32px;
    }

    .ct-page .ct-panel-head,
    .ct-page .ct-panel-body,
    .ct-page .ct-guide {
        padding: 21px;
    }

    .ct-page .ct-tools {
        padding: 20px;
    }

    .ct-page .ct-tools .ct-field {
        width: 100%;
    }

    .ct-page .ct-results {
        padding-bottom: 0;
    }
}
</style>

<div class="ct-page">

    <!-- Welcome -->
    <section class="ct-welcome" aria-labelledby="ct-title">
        <div>
            <span class="ct-eyebrow">Citizen Dashboard</span>

            <h1 id="ct-title">
                Welcome, <?php echo clean($user["name"]); ?>.
            </h1>

            <p>
                Help keep your community clean. Report waste,
                request a collection and follow the progress
                of your reports in one place.
            </p>
        </div>

        <a href="#ct-report-form" class="ct-btn ct-btn-lime">
            Report Waste <span aria-hidden="true">＋</span>
        </a>
    </section>

    <!-- Personal totals -->
    <div class="ct-stats">
        <article class="ct-stat">
            <span class="ct-stat-label">My Reports</span>
            <strong><?php echo number_format($totalReports); ?></strong>
            <p>Waste reports you have submitted</p>
        </article>

        <article class="ct-stat">
            <span class="ct-stat-label">Pickup Requests</span>
            <strong><?php echo number_format($totalPickups); ?></strong>
            <p>Reports where you requested pickup</p>
        </article>

        <article class="ct-stat">
            <span class="ct-stat-label">Completed</span>
            <strong><?php echo number_format($totalCompleted); ?></strong>
            <p>Reports marked as completed</p>
        </article>

        <article class="ct-stat">
            <span class="ct-stat-label">Recycled</span>
            <strong><?php echo number_format($totalRecycled); ?></strong>
            <p>Reports marked as recycled</p>
        </article>
    </div>

    <div class="ct-layout">

        <!-- Waste report form -->
        <section class="ct-panel" id="ct-report-form">
            <div class="ct-panel-head">
                <div>
                    <h2>Report Waste</h2>
                    <p>
                        Tell us what you found and where it is located.
                    </p>
                </div>
            </div>

            <div class="ct-panel-body">
                <p class="ct-required-note">
                    Fields marked <span class="ct-required">*</span>
                    are required.
                </p>

                <form action="citizen_action.php"
                      method="POST"
                      enctype="multipart/form-data">

                    <input type="hidden" name="action" value="report">

                    <div class="ct-form-grid">
                        <div class="ct-field">
                            <label for="ct-report-title">
                                Report Title
                                <span class="ct-required" aria-hidden="true">*</span>
                            </label>

                            <input
                                type="text"
                                id="ct-report-title"
                                name="title"
                                placeholder="e.g. Waste beside the park"
                                required
                            >
                        </div>

                        <div class="ct-field">
                            <label for="ct-waste-type">
                                Waste Type
                                <span class="ct-required" aria-hidden="true">*</span>
                            </label>

                            <select id="ct-waste-type" name="waste_type" required>
                                <option value="" disabled selected>
                                    Select waste type
                                </option>
                                <option>General Waste</option>
                                <option>Organic Waste</option>
                                <option>Plastic</option>
                                <option>Paper</option>
                                <option>Glass</option>
                                <option>Metal</option>
                                <option>Electronic Waste</option>
                                <option>Hazardous Waste</option>
                                <option>Construction Waste</option>
                            </select>
                        </div>

                        <div class="ct-field ct-full">
                            <label for="ct-description">
                                Description
                                <span class="ct-required" aria-hidden="true">*</span>
                            </label>

                            <textarea
                                id="ct-description"
                                name="description"
                                placeholder="Describe the waste, approximate amount and any useful details."
                                required
                            ></textarea>
                        </div>

                        <div class="ct-field ct-full">
                            <label for="ct-location">
                                Waste Location
                                <span class="ct-required" aria-hidden="true">*</span>
                            </label>

                            <input
                                type="text"
                                id="ct-location"
                                name="location"
                                placeholder="Street address or a clear location"
                                aria-describedby="ct-location-help"
                                required
                            >

                            <p class="ct-help" id="ct-location-help">
                                Include a nearby landmark if the location
                                is difficult to find.
                            </p>
                        </div>

                        <div class="ct-field ct-full">
                            <label for="ct-waste-image">
                                Waste Image
                                <span class="ct-optional">(optional)</span>
                            </label>

                            <div class="ct-upload">
                                <input
                                    type="file"
                                    id="ct-waste-image"
                                    name="waste_image"
                                    accept=".jpg,.jpeg,.png"
                                    aria-describedby="ct-image-help"
                                >

                                <p class="ct-help" id="ct-image-help">
                                    Choose a JPG or PNG photo showing the waste.
                                </p>

                                <figure class="ct-preview"
                                        id="ct-image-preview"
                                        hidden>
                                    <img id="ct-preview-image"
                                         alt="Preview of your selected waste photo">

                                    <figcaption>
                                        Selected photo preview
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    </div>

                    <div class="ct-options">
                        <label class="ct-checkbox" for="ct-pickup">
                            <input
                                type="checkbox"
                                id="ct-pickup"
                                name="pickup_requested"
                                value="1"
                            >

                            <span>
                                <strong>Request waste pickup</strong>
                                <span>
                                    Include a collection request with this report.
                                </span>
                            </span>
                        </label>

                        <label class="ct-checkbox" for="ct-recyclable">
                            <input
                                type="checkbox"
                                id="ct-recyclable"
                                name="recyclable"
                                value="1"
                            >

                            <span>
                                <strong>Contains recyclable materials</strong>
                                <span>
                                    Select this if the waste includes materials
                                    that may be recovered for recycling.
                                </span>
                            </span>
                        </label>
                    </div>

                    <button type="submit" class="ct-btn ct-btn-full">
                        Submit Report <span aria-hidden="true">→</span>
                    </button>
                </form>
            </div>
        </section>

        <div class="ct-sidebar">

            <!-- Profile -->
            <section class="ct-panel">
                <div class="ct-panel-head">
                    <div>
                        <h2>Your Profile</h2>
                        <p>Keep your name and contact details up to date.</p>
                    </div>
                </div>

                <div class="ct-panel-body">
                    <form action="citizen_action.php" method="POST">
                        <input type="hidden" name="action" value="profile">

                        <div class="ct-profile-grid">
                            <div class="ct-field">
                                <label for="ct-name">
                                    Full Name
                                    <span class="ct-required" aria-hidden="true">*</span>
                                </label>

                                <input
                                    type="text"
                                    id="ct-name"
                                    name="name"
                                    autocomplete="name"
                                    value="<?php echo clean($user["name"]); ?>"
                                    required
                                >
                            </div>

                            <div class="ct-field">
                                <label for="ct-phone">
                                    Phone
                                    <span class="ct-optional">(optional)</span>
                                </label>

                                <input
                                    type="tel"
                                    id="ct-phone"
                                    name="phone"
                                    autocomplete="tel"
                                    placeholder="Enter your phone number"
                                    value="<?php echo clean($user["phone"] ?? ""); ?>"
                                >
                            </div>

                            <div class="ct-field">
                                <label for="ct-address">
                                    Address
                                    <span class="ct-optional">(optional)</span>
                                </label>

                                <input
                                    type="text"
                                    id="ct-address"
                                    name="address"
                                    autocomplete="street-address"
                                    placeholder="Enter your address"
                                    value="<?php echo clean($user["address"] ?? ""); ?>"
                                >
                            </div>
                        </div>

                        <button type="submit" class="ct-btn ct-btn-full">
                            Save Profile
                        </button>
                    </form>
                </div>
            </section>

            <!-- Reporting guidance -->
            <aside class="ct-guide" aria-labelledby="ct-guide-title">
                <h3 id="ct-guide-title">Make your report useful</h3>

                <ul>
                    <li>
                        Use a short title that describes the issue.
                    </li>
                    <li>
                        Include the location and a nearby landmark.
                    </li>
                    <li>
                        Describe the type and approximate amount of waste.
                    </li>
                    <li>
                        Check your report history for status updates
                        after submitting.
                    </li>
                </ul>
            </aside>
        </div>

    </div>

    <!-- History -->
    <section class="ct-panel" id="ct-history">
        <div class="ct-panel-head">
            <div>
                <h2>Report &amp; Pickup History</h2>
                <p>
                    View your reports, assigned collectors and recorded
                    progress. Newest reports appear first.
                </p>
            </div>

            <span class="ct-count"><?php echo $totalReports; ?></span>
        </div>

        <div class="ct-tools" id="ct-history-tools" hidden>
            <div class="ct-field ct-search">
                <label for="ct-history-search">Search your reports</label>
                <input
                    type="search"
                    id="ct-history-search"
                    placeholder="Search ID, title, waste type or location"
                >
            </div>

            <div class="ct-field">
                <label for="ct-status-filter">Report Status</label>

                <select id="ct-status-filter">
                    <option value="">All statuses</option>

                    <?php foreach ($historyStatuses as $status): ?>
                        <option value="<?php echo clean($status); ?>">
                            <?php echo clean($status); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <span class="ct-results"
                  id="ct-history-count"
                  role="status"></span>
        </div>

        <div class="ct-table-wrap"
             tabindex="0"
             role="region"
             aria-label="Your report and pickup history">
            <table>
                <thead>
                    <tr>
                        <th scope="col">Report</th>
                        <th scope="col">Waste Details</th>
                        <th scope="col">Location</th>
                        <th scope="col">Collector</th>
                        <th scope="col">Report Status</th>
                        <th scope="col">Recycling</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($reports as $report): ?>
                        <tr
                            class="ct-history-row"
                            data-search="<?php echo clean(
                                $report["id"] . " " .
                                $report["title"] . " " .
                                $report["waste_type"] . " " .
                                $report["location"]
                            ); ?>"
                            data-status="<?php echo clean($report["status"]); ?>"
                        >
                            <td>
                                <strong>#<?php echo (int) $report["id"]; ?></strong>

                                <span class="ct-subtext">
                                    <?php echo clean($report["created_at"]); ?>
                                </span>
                            </td>

                            <td>
                                <div class="ct-waste-cell">
                                    <?php if (!empty($report["waste_image"])): ?>
                                        <?php
                                        $imageUrl = "uploads/" . rawurlencode(
                                            basename($report["waste_image"])
                                        );
                                        ?>

                                        <img
                                            class="ct-thumbnail"
                                            src="<?php echo clean($imageUrl); ?>"
                                            alt="<?php echo clean(
                                                "Waste photo: " . $report["title"]
                                            ); ?>"
                                            loading="lazy"
                                            width="60"
                                            height="60"
                                        >
                                    <?php else: ?>
                                        <span class="ct-thumbnail ct-no-image">
                                            No photo
                                        </span>
                                    <?php endif; ?>

                                    <div>
                                        <strong>
                                            <?php echo clean($report["title"]); ?>
                                        </strong>

                                        <span class="ct-subtext">
                                            <?php echo clean($report["waste_type"]); ?>
                                        </span>
                                    </div>
                                </div>
                            </td>

                            <td>
                                <?php echo clean($report["location"]); ?>
                            </td>

                            <td>
                                <?php echo clean(
                                    $report["collector_name"] ?? "Not assigned"
                                ); ?>
                            </td>

                            <td>
                                <span class="ct-badge <?php
                                    echo $statusClass($report["status"]);
                                ?>">
                                    <?php echo clean($report["status"]); ?>
                                </span>

                                <span class="ct-subtext">
                                    <?php echo (int) $report["pickup_requested"] === 1
                                        ? "Pickup requested"
                                        : "No pickup requested"; ?>
                                </span>
                            </td>

                            <td>
                                <?php if (!empty($report["recycling_status"])): ?>
                                    <span class="ct-badge <?php
                                        echo $statusClass($report["recycling_status"]);
                                    ?>">
                                        <?php echo clean($report["recycling_status"]); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="ct-subtext">
                                        No update
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <tr id="ct-history-empty"
                        <?php echo $reports ? "hidden" : ""; ?>>
                        <td colspan="6" class="ct-empty">
                            <?php echo $reports
                                ? "No reports match your search."
                                : "You have not submitted any reports yet. Use the form above to create your first report."; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>

</div>

<script>
(() => {
    "use strict";

    // Preview a selected image without uploading it.
    const imageInput = document.getElementById("ct-waste-image");
    const preview = document.getElementById("ct-image-preview");
    const previewImage = document.getElementById("ct-preview-image");

    let previewUrl = null;

    function clearPreview() {
        preview.hidden = true;
        previewImage.removeAttribute("src");

        if (previewUrl) {
            URL.revokeObjectURL(previewUrl);
            previewUrl = null;
        }
    }

    imageInput.addEventListener("change", () => {
        clearPreview();

        const file = imageInput.files[0];

        if (!file || !/\.(jpe?g|png)$/i.test(file.name)) {
            return;
        }

        previewUrl = URL.createObjectURL(file);
        previewImage.src = previewUrl;
    });

    previewImage.addEventListener("load", () => {
        preview.hidden = false;
    });

    previewImage.addEventListener("error", clearPreview);

    // Search and filter the user's loaded reports.
    const search = document.getElementById("ct-history-search");
    const statusFilter = document.getElementById("ct-status-filter");
    const counter = document.getElementById("ct-history-count");
    const emptyRow = document.getElementById("ct-history-empty");
    const tools = document.getElementById("ct-history-tools");

    const rows = Array.from(
        document.querySelectorAll(".ct-history-row")
    );

    function filterHistory() {
        const query = search.value.trim().toLocaleLowerCase();
        const selectedStatus = statusFilter.value;

        let visibleCount = 0;

        rows.forEach((row) => {
            const searchableText = row.dataset.search.toLocaleLowerCase();

            const matchesSearch = searchableText.includes(query);
            const matchesStatus = !selectedStatus ||
                row.dataset.status === selectedStatus;

            const visible = matchesSearch && matchesStatus;

            row.hidden = !visible;

            if (visible) {
                visibleCount++;
            }
        });

        emptyRow.hidden = visibleCount !== 0;

        counter.textContent =
            `${visibleCount} of ${rows.length} reports shown`;
    }

    tools.hidden = false;

    search.addEventListener("input", filterHistory);
    statusFilter.addEventListener("change", filterHistory);

    filterHistory();
})();
</script>

<?php require "footer.php"; ?>