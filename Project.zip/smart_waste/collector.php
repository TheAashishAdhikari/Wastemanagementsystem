<?php
require "config.php";

$user = requireRole("Collector");

$stmt = $pdo->prepare(
    "SELECT
        waste_reports.*,
        citizens.name AS citizen_name,
        citizens.phone AS citizen_phone
     FROM waste_reports
     JOIN users AS citizens
        ON citizens.id = waste_reports.citizen_id
     WHERE waste_reports.collector_id = ?
     ORDER BY waste_reports.created_at DESC"
);

$stmt->execute([$user["id"]]);
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

$totalJobs = count($jobs);
$awaitingAcceptance = 0;
$inProgress = 0;
$completed = 0;

foreach ($jobs as $job) {
    if ($job["status"] === "Assigned") {
        $awaitingAcceptance++;
    }

    if (in_array(
        $job["status"],
        ["Accepted", "On The Way", "Collected"],
        true
    )) {
        $inProgress++;
    }

    if ($job["status"] === "Completed") {
        $completed++;
    }
}

$availability = $user["availability"] ?? "";

$updateStatuses = [
    "Accepted",
    "On The Way",
    "Collected",
    "Completed"
];

$filterStatuses = array_unique(array_column($jobs, "status"));
sort($filterStatuses);

$badgeClass = static function ($status) {
    switch ($status) {
        case "Available":
        case "Collected":
        case "Completed":
            return "cl-green";

        case "Assigned":
            return "cl-amber";

        case "Rejected":
        case "Unavailable":
            return "cl-red";

        default:
            return "cl-blue";
    }
};

$pageTitle = "Collector Dashboard";
require "header.php";
?>

<style>
.cl-page {
    --cl-green: #176348;
    --cl-dark: #113f31;
    --cl-lime: #d8ee97;
    --cl-text: #20382b;
    --cl-muted: #506456;
    --cl-border: #dbe5d6;

    color: var(--cl-text);
    font-family: Arial, Helvetica, sans-serif;
    font-size: 16px;
    line-height: 1.6;
}

.cl-page *,
.cl-page *::before,
.cl-page *::after {
    box-sizing: border-box;
}

.cl-page [hidden] {
    display: none !important;
}

.cl-page h1,
.cl-page h2,
.cl-page h3,
.cl-page p {
    margin: 0;
}

.cl-page button,
.cl-page input,
.cl-page select,
.cl-page textarea {
    font: inherit;
}

.cl-page a:focus-visible,
.cl-page button:focus-visible,
.cl-page input:focus-visible,
.cl-page select:focus-visible,
.cl-page textarea:focus-visible,
.cl-page summary:focus-visible {
    outline: 3px solid #7ca460;
    outline-offset: 3px;
}

/* Welcome */
.cl-page .cl-welcome {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 25px;
    padding: 35px;
    border-radius: 20px;
    background:
        radial-gradient(ellipse at top right, #2c694c, transparent 65%),
        var(--cl-dark);
    color: #fff;
}

.cl-page .cl-eyebrow {
    display: block;
    margin-bottom: 12px;
    color: var(--cl-lime);
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
}

.cl-page h1 {
    font-size: clamp(29px, 3.5vw, 42px);
    line-height: 1.2;
    letter-spacing: -.7px;
    overflow-wrap: anywhere;
}

.cl-page .cl-welcome p {
    max-width: 650px;
    margin-top: 15px;
    color: #e0ece2;
    font-size: 16px;
    line-height: 1.8;
}

.cl-page .cl-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    min-height: 48px;
    padding: 12px 19px;
    border: 1px solid transparent;
    border-radius: 9px;
    background: var(--cl-green);
    color: #fff;
    font-size: 15px;
    font-weight: 700;
    line-height: 1.5;
    text-decoration: none;
    cursor: pointer;
}

.cl-page .cl-btn:hover {
    background: var(--cl-dark);
}

.cl-page .cl-btn-lime {
    flex-shrink: 0;
    background: var(--cl-lime);
    color: var(--cl-dark);
}

.cl-page .cl-btn-lime:hover {
    background: #c7e77f;
}

.cl-page .cl-btn-outline {
    border-color: #c9d8c1;
    background: #fff;
    color: var(--cl-green);
}

.cl-page .cl-btn-outline:hover {
    background: #edf4e5;
}

.cl-page .cl-btn-full {
    width: 100%;
}

/* Statistics */
.cl-page .cl-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin: 23px 0;
}

.cl-page .cl-stat {
    padding: 24px;
    border: 1px solid var(--cl-border);
    border-radius: 14px;
    background: #fff;
}

.cl-page .cl-stat-label {
    color: #39523f;
    font-size: 15px;
    font-weight: 700;
}

.cl-page .cl-stat strong {
    display: block;
    margin: 15px 0 9px;
    color: var(--cl-dark);
    font-size: 38px;
    line-height: 1;
    letter-spacing: -1px;
}

.cl-page .cl-stat p {
    color: var(--cl-muted);
    font-size: 14px;
    line-height: 1.7;
}

/* Availability */
.cl-page .cl-availability {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 25px;
    margin-bottom: 28px;
    padding: 25px;
    border: 1px solid var(--cl-border);
    border-radius: 15px;
    background: #fff;
}

.cl-page h2 {
    font-size: 25px;
    line-height: 1.3;
    letter-spacing: -.4px;
}

.cl-page .cl-availability p {
    margin: 9px 0 12px;
    color: var(--cl-muted);
    font-size: 15px;
    line-height: 1.7;
}

.cl-page .cl-availability-form {
    display: flex;
    align-items: flex-end;
    gap: 12px;
}

.cl-page .cl-availability-form select {
    min-width: 165px;
}

/* Shared fields */
.cl-page form {
    margin: 0;
}

.cl-page .cl-field {
    min-width: 0;
}

.cl-page .cl-field label {
    display: block;
    margin-bottom: 8px;
    color: #304b38;
    font-size: 15px;
    font-weight: 700;
}

.cl-page .cl-field input,
.cl-page .cl-field select,
.cl-page .cl-field textarea {
    display: block;
    width: 100%;
    min-height: 49px;
    margin: 0;
    padding: 12px 14px;
    border: 1px solid #cddac8;
    border-radius: 9px;
    background: #fff;
    color: var(--cl-text);
    font-size: 16px;
    line-height: 1.5;
}

.cl-page .cl-field textarea {
    min-height: 110px;
    resize: vertical;
}

.cl-page .cl-field input::placeholder,
.cl-page .cl-field textarea::placeholder {
    color: #647269;
    opacity: 1;
}

.cl-page .cl-field input:focus,
.cl-page .cl-field select:focus,
.cl-page .cl-field textarea:focus {
    border-color: var(--cl-green);
}

/* Badges */
.cl-page .cl-badge {
    display: inline-flex;
    align-items: center;
    padding: 6px 11px;
    border-radius: 7px;
    font-size: 13px;
    font-weight: 700;
    line-height: 1.5;
    white-space: nowrap;
}

.cl-page .cl-green {
    background: #e6f3e7;
    color: #27653a;
}

.cl-page .cl-amber {
    background: #fff1d5;
    color: #805710;
}

.cl-page .cl-red {
    background: #fbe8e3;
    color: #943c30;
}

.cl-page .cl-blue {
    background: #eaf0f5;
    color: #365a72;
}

/* Jobs and filters */
.cl-page .cl-jobs-section {
    scroll-margin-top: 110px;
}

.cl-page .cl-section-heading {
    margin-bottom: 20px;
}

.cl-page .cl-section-heading p {
    margin-top: 10px;
    color: var(--cl-muted);
    font-size: 15px;
    line-height: 1.8;
}

.cl-page .cl-tools {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 15px;
    margin-bottom: 22px;
    padding: 20px;
    border: 1px solid var(--cl-border);
    border-radius: 13px;
    background: #fff;
}

.cl-page .cl-search {
    flex: 1 1 280px;
}

.cl-page .cl-results {
    padding-bottom: 12px;
    color: var(--cl-muted);
    font-size: 14px;
}

.cl-page .cl-job-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    align-items: start;
    gap: 22px;
    margin-bottom: 25px;
}

.cl-page .cl-job {
    min-width: 0;
    border: 1px solid var(--cl-border);
    border-radius: 16px;
    background: #fff;
    overflow: hidden;
}

.cl-page .cl-job-head {
    padding: 25px;
    border-bottom: 1px solid var(--cl-border);
}

.cl-page .cl-job-topline {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 16px;
}

.cl-page .cl-job-id {
    color: #526b48;
    font-size: 14px;
    font-weight: 700;
}

.cl-page .cl-job h3 {
    color: var(--cl-text);
    font-size: 22px;
    line-height: 1.4;
    letter-spacing: -.3px;
    overflow-wrap: anywhere;
}

.cl-page .cl-job-body {
    padding: 25px;
}

.cl-page .cl-details {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
    margin: 0;
}

.cl-page .cl-details > div {
    min-width: 0;
}

.cl-page .cl-details dt {
    margin-bottom: 5px;
    color: var(--cl-muted);
    font-size: 14px;
}

.cl-page .cl-details dd {
    margin: 0;
    color: #2e4937;
    font-size: 16px;
    font-weight: 700;
    overflow-wrap: anywhere;
}

.cl-page .cl-details .cl-wide {
    grid-column: 1 / -1;
}

.cl-page .cl-accept-form {
    margin-top: 25px;
    padding-top: 22px;
    border-top: 1px solid var(--cl-border);
}

/* Expandable update controls */
.cl-page .cl-edit {
    margin-top: 22px;
    border-top: 1px solid var(--cl-border);
}

.cl-page .cl-edit summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    padding-top: 20px;
    color: var(--cl-green);
    font-size: 16px;
    font-weight: 700;
    list-style: none;
    cursor: pointer;
}

.cl-page .cl-edit summary::-webkit-details-marker {
    display: none;
}

.cl-page .cl-edit summary::after {
    content: "+";
    font-size: 24px;
}

.cl-page .cl-edit[open] summary::after {
    content: "−";
}

.cl-page .cl-status-form {
    display: grid;
    gap: 14px;
    margin-top: 20px;
}

.cl-page .cl-note-form {
    display: grid;
    gap: 14px;
    margin-top: 24px;
    padding-top: 24px;
    border-top: 1px solid var(--cl-border);
}

.cl-page .cl-saved-note {
    margin-top: 22px;
    padding: 17px;
    border: 1px solid var(--cl-border);
    border-radius: 10px;
    background: #f6f9f0;
}

.cl-page .cl-saved-note strong {
    font-size: 15px;
}

.cl-page .cl-saved-note p {
    margin-top: 8px;
    color: #465e40;
    font-size: 15px;
    line-height: 1.8;
    white-space: pre-wrap;
    overflow-wrap: anywhere;
}

.cl-page .cl-closed {
    margin-top: 23px;
    padding: 14px 16px;
    border-radius: 9px;
    background: #f1f5eb;
    color: #465e40;
    font-size: 14px;
    line-height: 1.7;
}

.cl-page .cl-empty {
    padding: 42px 25px;
    border: 1px solid var(--cl-border);
    border-radius: 15px;
    background: #fff;
    color: var(--cl-muted);
    text-align: center;
}

.cl-page .cl-empty h3 {
    margin-bottom: 10px;
    color: var(--cl-dark);
    font-size: 23px;
}

.cl-page .cl-empty p {
    font-size: 16px;
    line-height: 1.8;
}

@media (max-width: 1000px) {
    .cl-page .cl-stats {
        grid-template-columns: repeat(2, 1fr);
    }

    .cl-page .cl-availability {
        align-items: flex-start;
        flex-direction: column;
    }
}

@media (max-width: 760px) {
    .cl-page .cl-welcome {
        align-items: flex-start;
        flex-direction: column;
    }

    .cl-page .cl-job-grid {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 520px) {
    .cl-page .cl-welcome {
        padding: 26px;
    }

    .cl-page .cl-stats {
        gap: 10px;
    }

    .cl-page .cl-stat {
        padding: 18px;
    }

    .cl-page .cl-stat strong {
        font-size: 32px;
    }

    .cl-page .cl-availability,
    .cl-page .cl-job-head,
    .cl-page .cl-job-body {
        padding: 21px;
    }

    .cl-page .cl-availability-form {
        width: 100%;
        align-items: stretch;
        flex-direction: column;
    }

    .cl-page .cl-tools .cl-field {
        width: 100%;
    }

    .cl-page .cl-results {
        padding-bottom: 0;
    }

    .cl-page .cl-details {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="cl-page">

    <!-- Welcome -->
    <section class="cl-welcome" aria-labelledby="cl-title">
        <div>
            <span class="cl-eyebrow">Waste Collector Dashboard</span>

            <h1 id="cl-title">
                Welcome, <?php echo clean($user["name"]); ?>.
            </h1>

            <p>
                Review your assigned pickups, keep your availability
                up to date and record collection progress.
            </p>
        </div>

        <a href="#cl-pickups" class="cl-btn cl-btn-lime">
            View My Pickups <span aria-hidden="true">↓</span>
        </a>
    </section>

    <!-- Personal totals -->
    <div class="cl-stats">
        <article class="cl-stat">
            <span class="cl-stat-label">My Pickups</span>
            <strong><?php echo number_format($totalJobs); ?></strong>
            <p>All reports assigned to your account</p>
        </article>

        <article class="cl-stat">
            <span class="cl-stat-label">Awaiting Acceptance</span>
            <strong><?php echo number_format($awaitingAcceptance); ?></strong>
            <p>Jobs currently marked as assigned</p>
        </article>

        <article class="cl-stat">
            <span class="cl-stat-label">In Progress</span>
            <strong><?php echo number_format($inProgress); ?></strong>
            <p>Accepted, on the way or collected</p>
        </article>

        <article class="cl-stat">
            <span class="cl-stat-label">Completed</span>
            <strong><?php echo number_format($completed); ?></strong>
            <p>Jobs marked as completed</p>
        </article>
    </div>

    <!-- Availability -->
    <section class="cl-availability" aria-labelledby="cl-availability-title">
        <div>
            <h2 id="cl-availability-title">Your Availability</h2>

            <p>
                Let administrators know whether you are available
                for collection work.
            </p>

            <span class="cl-badge <?php echo $badgeClass($availability); ?>">
                <?php echo clean($availability ?: "Not set"); ?>
            </span>
        </div>

        <form action="collector_action.php"
              method="POST"
              class="cl-availability-form">

            <input type="hidden" name="action" value="availability">

            <div class="cl-field">
                <label for="cl-availability">Availability</label>

                <select name="availability"
                        id="cl-availability"
                        required>

                    <?php if (!in_array(
                        $availability,
                        ["Available", "Unavailable"],
                        true
                    )): ?>
                        <option value="" disabled selected>
                            Select availability
                        </option>
                    <?php endif; ?>

                    <option value="Available"
                        <?php echo $availability === "Available"
                            ? "selected" : ""; ?>>
                        Available
                    </option>

                    <option value="Unavailable"
                        <?php echo $availability === "Unavailable"
                            ? "selected" : ""; ?>>
                        Unavailable
                    </option>
                </select>
            </div>

            <button type="submit" class="cl-btn">
                Save Availability
            </button>
        </form>
    </section>

    <!-- Pickups -->
    <section class="cl-jobs-section"
             id="cl-pickups"
             aria-labelledby="cl-pickups-title">

        <div class="cl-section-heading">
            <h2 id="cl-pickups-title">My Assigned Pickups</h2>

            <p>
                Review location and citizen details, then update
                each job as your work progresses.
            </p>
        </div>

        <div class="cl-tools" id="cl-tools" hidden>
            <div class="cl-field cl-search">
                <label for="cl-search">Search pickups</label>

                <input
                    type="search"
                    id="cl-search"
                    placeholder="Search ID, waste, location or citizen"
                >
            </div>

            <div class="cl-field">
                <label for="cl-filter">Pickup Status</label>

                <select id="cl-filter">
                    <option value="">All statuses</option>

                    <?php foreach ($filterStatuses as $status): ?>
                        <option value="<?php echo clean($status); ?>">
                            <?php echo clean($status); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <span class="cl-results"
                  id="cl-result-count"
                  role="status"></span>
        </div>

        <div class="cl-job-grid">
            <?php foreach ($jobs as $job): ?>
                <?php
                $jobId = (int) $job["id"];

                $isClosed = in_array(
                    $job["status"],
                    ["Completed", "Rejected"],
                    true
                );
                ?>

                <article
                    class="cl-job"
                    data-search="<?php echo clean(
                        $jobId . " " .
                        $job["title"] . " " .
                        $job["waste_type"] . " " .
                        $job["location"] . " " .
                        $job["citizen_name"]
                    ); ?>"
                    data-status="<?php echo clean($job["status"]); ?>"
                >
                    <div class="cl-job-head">
                        <div class="cl-job-topline">
                            <span class="cl-job-id">
                                Pickup #<?php echo $jobId; ?>
                            </span>

                            <span class="cl-badge <?php
                                echo $badgeClass($job["status"]);
                            ?>">
                                <?php echo clean($job["status"]); ?>
                            </span>
                        </div>

                        <h3><?php echo clean($job["title"]); ?></h3>
                    </div>

                    <div class="cl-job-body">
                        <dl class="cl-details">
                            <div>
                                <dt>Waste Type</dt>
                                <dd><?php echo clean($job["waste_type"]); ?></dd>
                            </div>

                            <div>
                                <dt>Citizen</dt>
                                <dd><?php echo clean($job["citizen_name"]); ?></dd>
                            </div>

                            <div class="cl-wide">
                                <dt>Collection Location</dt>
                                <dd><?php echo clean($job["location"]); ?></dd>
                            </div>

                            <div class="cl-wide">
                                <dt>Phone</dt>
                                <dd>
                                    <?php echo clean(
                                        !empty($job["citizen_phone"])
                                            ? $job["citizen_phone"]
                                            : "Not provided"
                                    ); ?>
                                </dd>
                            </div>
                        </dl>

                        <?php if ($job["status"] === "Assigned"): ?>
                            <form action="collector_action.php"
                                  method="POST"
                                  class="cl-accept-form">

                                <input type="hidden"
                                       name="action"
                                       value="accept">

                                <input type="hidden"
                                       name="report_id"
                                       value="<?php echo $jobId; ?>">

                                <button type="submit"
                                        class="cl-btn cl-btn-full">
                                    Accept Pickup
                                    <span aria-hidden="true">✓</span>
                                </button>
                            </form>
                        <?php endif; ?>

                        <?php if (!$isClosed): ?>
                            <details class="cl-edit">
                                <summary>Update Progress &amp; Notes</summary>

                                <form action="collector_action.php"
                                      method="POST"
                                      class="cl-status-form">

                                    <input type="hidden"
                                           name="action"
                                           value="status">

                                    <input type="hidden"
                                           name="report_id"
                                           value="<?php echo $jobId; ?>">

                                    <div class="cl-field">
                                        <label for="cl-status-<?php echo $jobId; ?>">
                                            Update Pickup Status
                                        </label>

                                        <select name="status"
                                                id="cl-status-<?php echo $jobId; ?>"
                                                required>

                                            <?php if (!in_array(
                                                $job["status"],
                                                $updateStatuses,
                                                true
                                            )): ?>
                                                <option value="" disabled selected>
                                                    Select an updated status
                                                </option>
                                            <?php endif; ?>

                                            <?php foreach ($updateStatuses as $status): ?>
                                                <option
                                                    value="<?php echo clean($status); ?>"
                                                    <?php echo $job["status"] === $status
                                                        ? "selected" : ""; ?>
                                                >
                                                    <?php echo clean($status); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>

                                    <button type="submit" class="cl-btn">
                                        Save Status
                                    </button>
                                </form>

                                <form action="collector_action.php"
                                      method="POST"
                                      class="cl-note-form">

                                    <input type="hidden"
                                           name="action"
                                           value="note">

                                    <input type="hidden"
                                           name="report_id"
                                           value="<?php echo $jobId; ?>">

                                    <div class="cl-field">
                                        <label for="cl-note-<?php echo $jobId; ?>">
                                            Collection Note
                                        </label>

                                        <textarea
                                            name="collection_note"
                                            id="cl-note-<?php echo $jobId; ?>"
                                            placeholder="Add collection details, access issues or progress notes."
                                            required
                                        ><?php echo clean(
                                            $job["collection_note"] ?? ""
                                        ); ?></textarea>
                                    </div>

                                    <button type="submit"
                                            class="cl-btn cl-btn-outline">
                                        Save Note
                                    </button>
                                </form>
                            </details>

                        <?php else: ?>

                            <p class="cl-closed">
                                This pickup is
                                <?php echo clean(strtolower($job["status"])); ?>.
                                Updates are no longer available here.
                            </p>

                            <?php if (!empty($job["collection_note"])): ?>
                                <div class="cl-saved-note">
                                    <strong>Collection Note</strong>
                                    <p><?php echo clean($job["collection_note"]); ?></p>
                                </div>
                            <?php endif; ?>

                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <div class="cl-empty"
             id="cl-empty"
             <?php echo $jobs ? "hidden" : ""; ?>>

            <h3>
                <?php echo $jobs
                    ? "No matching pickups"
                    : "No pickups assigned yet"; ?>
            </h3>

            <p>
                <?php echo $jobs
                    ? "Try another search or choose a different status."
                    : "Your assigned collection jobs will appear here. Keep your availability up to date."; ?>
            </p>
        </div>
    </section>

</div>

<script>
(() => {
    "use strict";

    const search = document.getElementById("cl-search");
    const filter = document.getElementById("cl-filter");
    const counter = document.getElementById("cl-result-count");
    const empty = document.getElementById("cl-empty");
    const tools = document.getElementById("cl-tools");

    const jobs = Array.from(
        document.querySelectorAll(".cl-job")
    );

    function filterJobs() {
        const query = search.value.trim().toLocaleLowerCase();
        const selectedStatus = filter.value;

        let visibleCount = 0;

        jobs.forEach((job) => {
            const searchableText =
                (job.dataset.search || "").toLocaleLowerCase();

            const matchesSearch = searchableText.includes(query);

            const matchesStatus = !selectedStatus ||
                job.dataset.status === selectedStatus;

            const visible = matchesSearch && matchesStatus;

            job.hidden = !visible;

            if (visible) {
                visibleCount++;
            }
        });

        empty.hidden = visibleCount !== 0;

        counter.textContent =
            `${visibleCount} of ${jobs.length} pickups shown`;
    }

    tools.hidden = false;

    search.addEventListener("input", filterJobs);
    filter.addEventListener("change", filterJobs);
    window.addEventListener("pageshow", filterJobs);

    filterJobs();
})();
</script>

<?php require "footer.php"; ?>