<?php
$user = currentUser();
$pageTitle = $pageTitle ?? "Smart Waste Management System";

$currentPage = basename($_SERVER["SCRIPT_NAME"]);

$dashboardPages = [
    "Citizen" => "citizen.php",
    "Collector" => "collector.php",
    "Recycler" => "recycler.php",
    "Admin" => "admin.php"
];

$dashboardUrl = $user
    ? ($dashboardPages[$user["role"]] ?? null)
    : null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo clean($pageTitle); ?></title>

    <link rel="stylesheet" href="style.css?v=11">

    <style>
        html {
            scroll-behavior: smooth;
        }

        body {
            margin: 0;
        }

        #sw-login,
        #sw-how-it-works {
            scroll-margin-top: 110px;
        }

        /* Accessible keyboard shortcut to the page content */
        .sw-skip-link {
            position: fixed;
            top: -100px;
            left: 20px;
            z-index: 2000;
            padding: 12px 18px;
            border-radius: 8px;
            background: #113f31;
            color: #fff;
            font-family: Arial, Helvetica, sans-serif;
            text-decoration: none;
        }

        .sw-skip-link:focus {
            top: 12px;
        }

        /* Header */
        header.sw-header {
            position: sticky;
            top: 0;
            z-index: 1000;
            display: block;
            padding: 0;
            border-bottom: 1px solid #dfe7df;
            background: #f9fbf6;
            color: #172e26;
            font-family: Arial, Helvetica, sans-serif;
            box-shadow: 0 4px 20px rgba(17, 63, 49, 0.04);
        }

        .sw-header *,
        .sw-header *::before,
        .sw-header *::after {
            box-sizing: border-box;
        }

        .sw-header .sw-header-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            width: 92%;
            max-width: 1300px;
            min-height: 86px;
            margin: 0 auto;
        }

        /* Brand */
        .sw-header .sw-brand {
            display: inline-flex;
            align-items: center;
            gap: 12px;
            flex-shrink: 0;
            color: #172e26;
            text-decoration: none;
        }

        .sw-header .sw-brand-mark {
            display: grid;
            place-items: center;
            width: 46px;
            height: 46px;
            border: 1px solid #245b45;
            border-radius: 14px;
            background: #113f31;
            color: #d8ee97;
            font-size: 31px;
            line-height: 1;
        }

        .sw-header .sw-brand-text {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }

        .sw-header .sw-brand-name {
            font-size: 19px;
            font-weight: 800;
            letter-spacing: -0.6px;
            line-height: 1.1;
        }

        .sw-header .sw-brand-caption {
            color: #647568;
            font-size: 9px;
            font-weight: 700;
            letter-spacing: 1.8px;
            text-transform: uppercase;
        }

        /* Navigation */
        .sw-header .sw-nav {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            gap: 8px;
        }

        .sw-header .sw-nav-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 44px;
            padding: 11px 15px;
            border: 1px solid transparent;
            border-radius: 8px;
            color: #52675a;
            background: transparent;
            font-size: 13px;
            font-weight: 700;
            line-height: 1.4;
            text-decoration: none;
            transition: background .2s, color .2s;
        }

        .sw-header .sw-nav-link:hover {
            background: #eaf0e4;
            color: #113f31;
        }

        .sw-header .sw-nav-link[aria-current="page"] {
            background: #e7eedf;
            color: #113f31;
        }

        .sw-header .sw-nav-login {
            margin-left: 8px;
            border-color: #d5dfd1;
            color: #176348;
        }

        .sw-header .sw-nav-primary {
            gap: 14px;
            padding-right: 19px;
            padding-left: 19px;
            background: #176348;
            color: #fff;
        }

        .sw-header .sw-nav-primary:hover,
        .sw-header .sw-nav-primary[aria-current="page"] {
            background: #113f31;
            color: #fff;
        }

        .sw-header .sw-nav-logout {
            border-color: #d5dfd1;
            color: #52675a;
        }

        .sw-header .sw-role-badge {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            margin: 0 8px;
            padding: 8px 11px;
            border-radius: 30px;
            background: #eaf0e4;
            color: #31563e;
            font-size: 11px;
            font-weight: 700;
        }

        .sw-header .sw-role-dot {
            width: 6px;
            height: 6px;
            border-radius: 50%;
            background: #588b3e;
        }

        .sw-header a:focus-visible,
        .sw-header button:focus-visible {
            outline: 3px solid #81a65a;
            outline-offset: 4px;
        }

        /* Mobile menu button */
        .sw-header .sw-menu-toggle {
            display: none;
            align-items: center;
            justify-content: center;
            gap: 9px;
            min-height: 44px;
            padding: 10px 13px;
            border: 1px solid #d5dfd1;
            border-radius: 8px;
            background: #fff;
            color: #113f31;
            font: inherit;
            font-size: 12px;
            font-weight: 700;
            cursor: pointer;
        }

        .sw-header .sw-menu-icon {
            position: relative;
            display: block;
            width: 17px;
            height: 12px;
            border-top: 2px solid currentColor;
            border-bottom: 2px solid currentColor;
        }

        .sw-header .sw-menu-icon::before {
            content: "";
            position: absolute;
            top: 3px;
            left: 0;
            width: 17px;
            border-top: 2px solid currentColor;
        }

        /* Session notification */
        .sw-flash {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin-bottom: 24px;
            padding: 17px 20px;
            border: 1px solid #d6e1d1;
            border-left: 4px solid #176348;
            border-radius: 10px;
            background: #f0f5eb;
            color: #244632;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 14px;
            line-height: 1.7;
            overflow-wrap: anywhere;
        }

        .sw-flash-icon {
            display: grid;
            place-items: center;
            flex: 0 0 22px;
            height: 22px;
            margin-top: 1px;
            border: 1px solid #7e9970;
            border-radius: 50%;
            font-size: 12px;
            font-weight: 700;
        }

        @media (max-width: 820px) {
            .sw-header .sw-header-inner {
                flex-wrap: wrap;
                gap: 0;
                min-height: 78px;
                padding: 15px 0;
            }

            .sw-header .sw-brand-mark {
                width: 41px;
                height: 41px;
                border-radius: 12px;
                font-size: 28px;
            }

            .sw-header .sw-brand-name {
                font-size: 17px;
            }

            .sw-header .sw-brand-caption {
                font-size: 8px;
                letter-spacing: 1.3px;
            }

            .sw-header .sw-nav {
                width: 100%;
                margin-top: 15px;
                padding-top: 15px;
                border-top: 1px solid #dfe7df;
            }

            /* Navigation stays available if JavaScript is disabled. */
            .sw-header.sw-menu-ready .sw-menu-toggle {
                display: inline-flex;
            }

            .sw-header.sw-menu-ready .sw-nav {
                display: none;
            }

            .sw-header.sw-menu-ready .sw-nav.is-open {
                display: flex;
            }

            .sw-header .sw-nav-link {
                justify-content: flex-start;
                width: 100%;
                min-height: 46px;
                padding: 12px 15px;
            }

            .sw-header .sw-nav-login {
                margin-left: 0;
            }

            .sw-header .sw-nav-primary {
                justify-content: space-between;
            }

            .sw-header .sw-role-badge {
                margin: 0 0 8px;
            }
        }

        @media (max-width: 380px) {
            .sw-header .sw-brand {
                gap: 8px;
            }

            .sw-header .sw-brand-name {
                font-size: 15px;
            }

            .sw-header .sw-brand-caption {
                font-size: 7px;
                letter-spacing: 1px;
            }

            .sw-header .sw-menu-toggle {
                padding: 10px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            html {
                scroll-behavior: auto;
            }

            .sw-header .sw-nav-link {
                transition: none;
            }
        }
    </style>
</head>

<body>

<a href="#main-content" class="sw-skip-link">
    Skip to main content
</a>

<header class="sw-header" id="sw-site-header">
    <div class="sw-header-inner">

        <a
            class="sw-brand"
            href="index.php"
            aria-label="Smart Waste Management home"
        >
            <span class="sw-brand-mark" aria-hidden="true">♻</span>

            <span class="sw-brand-text">
                <span class="sw-brand-name">Smart Waste</span>
                <span class="sw-brand-caption">Management System</span>
            </span>
        </a>

        <button
            type="button"
            class="sw-menu-toggle"
            id="sw-menu-toggle"
            aria-expanded="false"
            aria-controls="sw-main-nav"
        >
            <span class="sw-menu-icon" aria-hidden="true"></span>
            <span>Menu</span>
        </button>

        <nav
            class="sw-nav"
            id="sw-main-nav"
            aria-label="Main navigation"
        >
            <?php if ($user): ?>

                <span class="sw-role-badge">
                    <span class="sw-role-dot" aria-hidden="true"></span>
                    <?php echo clean($user["role"]); ?>
                </span>

                <?php if ($dashboardUrl): ?>
                    <a
                        href="<?php echo clean($dashboardUrl); ?>"
                        class="sw-nav-link"
                        <?php if ($currentPage === $dashboardUrl): ?>
                            aria-current="page"
                        <?php endif; ?>
                    >
                        Dashboard
                    </a>
                <?php endif; ?>

                <a href="logout.php" class="sw-nav-link sw-nav-logout">
                    Logout
                </a>

            <?php else: ?>

                <a
                    href="index.php"
                    class="sw-nav-link"
                    <?php if ($currentPage === "index.php"): ?>
                        aria-current="page"
                    <?php endif; ?>
                >
                    Home
                </a>

                <a
                    href="index.php#sw-how-it-works"
                    class="sw-nav-link"
                >
                    How It Works
                </a>

                <a
                    href="index.php#sw-login"
                    class="sw-nav-link sw-nav-login"
                >
                    Login
                </a>

                <a
                    href="register.php"
                    class="sw-nav-link sw-nav-primary"
                    <?php if ($currentPage === "register.php"): ?>
                        aria-current="page"
                    <?php endif; ?>
                >
                    Create Account
                    <span aria-hidden="true">↗</span>
                </a>

            <?php endif; ?>
        </nav>

    </div>
</header>

<script>
(() => {
    "use strict";

    const header = document.getElementById("sw-site-header");
    const toggle = document.getElementById("sw-menu-toggle");
    const navigation = document.getElementById("sw-main-nav");
    const mobileViewport = window.matchMedia("(max-width: 820px)");

    if (!header || !toggle || !navigation) {
        return;
    }

    header.classList.add("sw-menu-ready");

    function closeMenu() {
        navigation.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
    }

    toggle.addEventListener("click", () => {
        const isOpen = navigation.classList.toggle("is-open");
        toggle.setAttribute("aria-expanded", String(isOpen));
    });

    navigation.addEventListener("click", (event) => {
        const link = event.target.closest("a");

        if (!link || !mobileViewport.matches) {
            return;
        }

        // Move focus out of the menu before hiding its links.
        toggle.focus({ preventScroll: true });
        closeMenu();
    });

    document.addEventListener("keydown", (event) => {
        if (
            event.key === "Escape" &&
            navigation.classList.contains("is-open")
        ) {
            closeMenu();
            toggle.focus();
        }
    });

    document.addEventListener("click", (event) => {
        if (!header.contains(event.target)) {
            closeMenu();
        }
    });

    mobileViewport.addEventListener("change", () => {
        if (mobileViewport.matches &&
            navigation.contains(document.activeElement)) {
            toggle.focus({ preventScroll: true });
        }

        closeMenu();
    });
})();
</script>

<main class="container" id="main-content" tabindex="-1">

<?php if (isset($_SESSION["message"])): ?>
    <div class="sw-flash" role="status">
        <span class="sw-flash-icon" aria-hidden="true">i</span>

        <span>
            <?php echo clean($_SESSION["message"]); ?>
        </span>
    </div>

    <?php unset($_SESSION["message"]); ?>
<?php endif; ?>