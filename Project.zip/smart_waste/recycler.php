<?php
require "config.php";

$user = requireRole("Recycler");

$available = $pdo->query(
    "SELECT *
     FROM waste_reports
     WHERE recyclable = 1
     AND recycling_status = 'Available'
     ORDER BY created_at DESC"
)->fetchAll(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare(
    "SELECT *
     FROM waste_reports
     WHERE recycler_id = ?
     ORDER BY created_at DESC"
);

$stmt->execute([$user["id"]]);
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

$companyName = !empty($user["company_name"])
    ? $user["company_name"]
    : $user["name"];

$recycledCount = 0;
$recycledKg = 0;

foreach ($records as $record) {
    if ($record["recycling_status"] === "Recycled") {
        $recycledCount++;
        $recycledKg += (float) ($record["quantity_kg"] ?? 0);
    }
}

$recyclingStatuses = [
    "Requested",
    "Collected",
    "Processing",
    "Recycled",
    "Rejected"
];

$wasteTypes = array_unique(array_column($available, "waste_type"));
sort($wasteTypes);

$badgeClass = static function ($status) {
    switch ($status) {
        case "Available":
        case "Recycled":
            return "rc-green";

        case "Requested":
            return "rc-amber";

        case "Rejected":
            return "rc-red";

        default:
            return "rc-blue";
    }
};

$pageTitle = "Recycling Company Dashboard";
require "header.php";
?>

<style>
.rc-page {
    --rc-dark: #113f31;
    --rc-green: #176348;
    --rc-lime: #d8ee97;
    --rc-text: #20382b;
    --rc-muted: #506456;
    --rc-border: #dbe5d6;
    color: var(--rc-text);
    font-family: Arial, Helvetica, sans-serif;
    font-size: 16px;
    line-height: 1.6;
}

.rc-page *,
.rc-page *::before,
.rc-page *::after {
    box-sizing: border-box;
}

.rc-page [hidden] {
    display: none !important;
}

.rc-page h1,
.rc-page h2,
.rc-page h3,
.rc-page p {
    margin: 0;
}

.rc-page button,
.rc-page input,
.rc-page select,
.rc-page textarea {
    font: inherit;
}

.rc-page a:focus-visible,
.rc-page button:focus-visible,
.rc-page input:focus-visible,
.rc-page select:focus-visible,
.rc-page textarea:focus-visible,
.rc-page summary:focus-visible,
.rc-page .rc-table-wrap:focus-visible {
    outline: 3px solid #7ca460;
    outline-offset: 3px;
}

/* Welcome */
.rc-page .rc-welcome {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 25px;
    padding: 36px;
    border-radius: 20px;
    background:
        radial-gradient(ellipse at top right, #2c694c, transparent 65%),
        var(--rc-dark);
    color: #fff;
}

.rc-page .rc-eyebrow {
    display: block;
    margin-bottom: 13px;
    color: var(--rc-lime);
    font-size: 13px;
    font-weight: 700;
    letter-spacing: 1px;
    text-transform: uppercase;
}

.rc-page h1 {
    font-size: clamp(29px, 3.5vw, 42px);
    line-height: 1.2;
    letter-spacing: -.7px;
    overflow-wrap: anywhere;
}

.rc-page .rc-welcome p {
    max-width: 640px;
    margin-top: 15px;
    color: #e0ece2;
    font-size: 16px;
    line-height: 1.8;
}

.rc-page .rc-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 12px;
    min-height: 48px;
    padding: 12px 19px;
    border: 1px solid transparent;
    border-radius: 9px;
    background: var(--rc-green);
    color: #fff;
    font-size: 15px;
    font-weight: 700;
    line-height: 1.5;
    text-decoration: none;
    cursor: pointer;
}

.rc-page .rc-btn:hover {
    background: var(--rc-dark);
}

.rc-page .rc-btn-lime {
    flex-shrink: 0;
    background: var(--rc-lime);
    color: var(--rc-dark);
}

.rc-page .rc-btn-lime:hover {
    background: #c7e77f;
}

/* Totals */
.rc-page .rc-stats {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 16px;
    margin: 23px 0;
}

.rc-page .rc-stat {
    padding: 24px;
    border: 1px solid var(--rc-border);
    border-radius: 14px;
    background: #fff;
}

.rc-page .rc-stat-label {
    color: #39523f;
    font-size: 15px;
    font-weight: 700;
}

.rc-page .rc-stat strong {
    display: block;
    margin: 15px 0 9px;
    color: var(--rc-dark);
    font-size: 36px;
    line-height: 1.1;
    letter-spacing: -1px;
    overflow-wrap: anywhere;
}

.rc-page .rc-stat p {
    color: var(--rc-muted);
    font-size: 14px;
    line-height: 1.7;
}

.rc-page .rc-stat-unit {
    font-size: 18px;
    font-weight: 400;
    letter-spacing: 0;
}

/* Section navigation */
.rc-page .rc-nav {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    margin: 24px 0;
}

.rc-page .rc-nav a {
    padding: 11px 17px;
    border: 1px solid var(--rc-border);
    border-radius: 9px;
    background: #fff;
    color: var(--rc-dark);
    font-size: 15px;
    font-weight: 700;
    text-decoration: none;
}

.rc-page .rc-nav a:hover {
    background: #edf4e5;
}

/* Panels */
.rc-page .rc-panel {
    margin-bottom: 25px;
    border: 1px solid var(--rc-border);
    border-radius: 16px;
    background: #fff;
    overflow: hidden;
    scroll-margin-top: 110px;
}

.rc-page .rc-panel-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 25px;
    border-bottom: 1px solid var(--rc-border);
}

.rc-page h2 {
    font-size: 25px;
    line-height: 1.3;
    letter-spacing: -.4px;
}

.rc-page .rc-panel-head p {
    margin-top: 9px;
    color: var(--rc-muted);
    font-size: 15px;
    line-height: 1.8;
}

.rc-page .rc-count {
    display: grid;
    place-items: center;
    min-width: 37px;
    min-height: 37px;
    padding: 5px 10px;
    border-radius: 9px;
    background: #edf4e5;
    color: var(--rc-green);
    font-size: 15px;
    font-weight: 700;
}

/* Forms and filters */
.rc-page form {
    margin: 0;
}

.rc-page .rc-tools {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 15px;
    padding: 20px 25px;
    border-bottom: 1px solid var(--rc-border);
    background: #fafcf6;
}

.rc-page .rc-field {
    min-width: 0;
}

.rc-page .rc-search {
    flex: 1 1 260px;
}

.rc-page .rc-field label {
    display: block;
    margin-bottom: 8px;
    color: #304b38;
    font-size: 15px;
    font-weight: 700;
}

.rc-page .rc-field input,
.rc-page .rc-field select,
.rc-page .rc-field textarea {
    display: block;
    width: 100%;
    min-height: 49px;
    margin: 0;
    padding: 12px 14px;
    border: 1px solid #cddac8;
    border-radius: 9px;
    background: #fff;
    color: var(--rc-text);
    font-size: 16px;
    line-height: 1.5;
}

.rc-page .rc-field textarea {
    min-height: 115px;
    resize: vertical;
}

.rc-page .rc-field input::placeholder,
.rc-page .rc-field textarea::placeholder {
    color: #647269;
    opacity: 1;
}

.rc-page .rc-field input:focus,
.rc-page .rc-field select:focus,
.rc-page .rc-field textarea:focus {
    border-color: var(--rc-green);
}

.rc-page .rc-results {
    padding-bottom: 12px;
    color: var(--rc-muted);
    font-size: 14px;
}

.rc-page .rc-help {
    margin-top: 8px;
    color: var(--rc-muted);
    font-size: 14px;
    line-height: 1.7;
}

/* Available waste table */
.rc-page .rc-table-wrap {
    overflow-x: auto;
}

.rc-page table {
    width: 100%;
    margin: 0;
    border-collapse: collapse;
    text-align: left;
}

.rc-page th {
    padding: 16px 23px;
    border: 0;
    border-bottom: 1px solid var(--rc-border);
    background: #f1f6e9;
    color: #35503b;
    font-size: 14px;
    white-space: nowrap;
}

.rc-page td {
    padding: 20px 23px;
    border: 0;
    border-bottom: 1px solid #e9eee4;
    background: #fff;
    color: #334c3b;
    font-size: 15px;
    line-height: 1.7;
    vertical-align: middle;
}

.rc-page tbody tr:last-child td {
    border-bottom: 0;
}

.rc-page .rc-table-wrap .rc-btn {
    white-space: nowrap;
}

.rc-page .rc-subtext {
    display: block;
    margin-top: 5px;
    color: var(--rc-muted);
    font-size: 14px;
}

/* Status badges */
.rc.rc-page .rc-badge {
    display: inline-flex;
    align-items: center;
    padding: 6px 11px;
    border-radius: 7px;
    font-size: 13px;
    font-weight: 700;
    line-height: 1.5;
    white-space: nowrap;
}

.rc-page .rc-green {
    background: #e6f3e7;
    color: #27653a;
}

.rc-page .rc-amber {
    background: #fff1d5;
    color: #805710;
}

.rc-page .rc-red {
    background: #fbe8e3;
    color: #943c30;
}

.rc-page .rc-blue {
    background: #eaf0f5;
    color: #365a72;
}

/* Recycling records */
.rc-page .rc-record-list {
    display: grid;
    gap: 16px;
    padding: 23px;
}

.rc-page .rc-record {
    min-width: 0;
    border: 1px solid var(--rc-border);
    border-radius: 12px;
    overflow: hidden;
}

.rc-page .rc-record summary {
    display: flex;
    align-items: center;
    gap: 20px;
    padding: 23px;
    list-style: none;
    cursor: pointer;
}

.rc-page .rc-record summary::-webkit-details-marker {
    display: none;
}

.rc-page .rc-record summary::after {
    content: "+";
    flex-shrink: 0;
    margin-left: auto;
    color: var(--rc-green);
    font-size: 26px;
}

.rc-page .rc-record[open] summary::after {
    content: "−";
}

.rc-page .rc-record-name {
    flex: 1;
    min-width: 0;
}

.rc-page .rc-record-title {
    display: block;
    color: var(--rc-text);
    font-size: 18px;
    font-weight: 700;
    overflow-wrap: anywhere;
}

.rc-page .rc-record-id {
    color: #566b4e;
}

.rc-page .rc-record-tags {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 10px;
    margin-top: 13px;
}

.rc-page .rc-quantity {
    color: #3b5542;
    font-size: 14px;
    font-weight: 700;
}

.rc-page .rc-record-form {
    padding: 23px;
    border-top: 1px solid var(--rc-border);
    background: #fafcf6;
}

.rc-page .rc-form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 21px;
}

.rc-page .rc-full {
    grid-column: 1 / -1;
}

.rc-page .rc-form-footer {
    display: flex;
    justify-content: flex-end;
    margin-top: 23px;
}

.rc-page .rc-empty {
    padding: 35px 25px;
    color: var(--rc-muted);
    font-size: 16px;
    line-height: 1.8;
    text-align: center;
}

@media (max-width: 1000px) {
    .rc-page .rc-stats {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media (max-width: 760px) {
    .rc-page .rc-welcome {
        flex-direction: column;
        align-items: flex-start;
    }
}

@media (max-width: 520px) {
    .rc-page .rc-welcome {
        padding: 26px;
    }

    .rc-page .rc-stats {
        gap: 10px;
    }

    .rc-page .rc-stat {
        padding: 18px;
    }

    .rc-page .rc-stat strong {
        font-size: 30px;
    }

    .rc-page .rc-panel-head,
    .rc-page .rc-tools {
        padding: 21px;
    }

    .rc-page .rc-tools .rc-field {
        width: 100%;
    }

    .rc-page .rc-results {
        padding-bottom: 0;
    }

    .rc-page .rc-record-list {
        padding: 14px;
    }

    .rc-page .rc-record summary,
    .rc-page .rc-record-form {
        padding: 19px;
    }

    .rc-page .rc-form-grid {
        grid-template-columns: 1fr;
    }

    .rc-page .rc-form-footer .rc-btn {
        width: 100%;
    }

    .rc-page .rc-nav a {
        flex: 1;
        text-align: center;
    }
}
</style>

<div class="rc-page">

    <!-- Welcome -->
    <section class="rc-welcome" aria-labelledby="rc-title">
        <div>
            <span class="rc-eyebrow">Recycling Company Dashboard</span>

            <h1 id="rc-title">
                <?php echo clean($companyName); ?>
            </h1>

            <p>
                Give useful materials a second life. Explore available
                recyclable waste, request collections and maintain
                your recycling records.
            </p>
        </div>

        <a href="#rc-available" class="rc-btn rc-btn-lime">
            Browse Materials <span aria-hidden="true">↓</span>
        </a>
    </section>

    <!-- Database totals -->
    <div class="rc-stats">
        <article class="rc-stat">
            <span class="rc-stat-label">Available Listings</span>
            <strong><?php echo number_format(count($available)); ?></strong>
            <p>Recyclable reports currently available</p>
        </article>

        <article class="rc-stat">
            <span class="rc-stat-label">My Records</span>
            <strong><?php echo number_format(count($records)); ?></strong>
            <p>Reports linked to your account</p>
        </article>

        <article class="rc-stat">
            <span class="rc-stat-label">Recycled Records</span>
            <strong><?php echo number_format($recycledCount); ?></strong>
            <p>Your records marked as recycled</p>
        </article>

        <article class="rc-stat">
            <span class="rc-stat-label">Recorded Recycled Weight</span>
            <strong>
                <?php echo number_format($recycledKg, 2); ?>
                <span class="rc-stat-unit">kg</span>
            </strong>
            <p>Entered quantities on your recycled records</p>
        </article>
    </div>

    <nav class="rc-nav" aria-label="Recycling dashboard sections">
        <a href="#rc-available">Available Waste</a>
        <a href="#rc-records">My Recycling Records</a>
    </nav>

    <!-- Available recyclable waste -->
    <section class="rc-panel" id="rc-available">
        <div class="rc-panel-head">
            <div>
                <h2>Available Recyclable Waste</h2>
                <p>
                    Review the material type and location before
                    requesting a collection.
                </p>
            </div>

            <span class="rc-count">
                <?php echo count($available); ?>
            </span>
        </div>

        <div class="rc-tools" id="rc-available-tools" hidden>
            <div class="rc-field rc-search">
                <label for="rc-available-search">Search listings</label>
                <input
                    type="search"
                    id="rc-available-search"
                    placeholder="Search ID, title or location"
                >
            </div>

            <div class="rc-field">
                <label for="rc-type-filter">Waste Type</label>
                <select id="rc-type-filter">
                    <option value="">All types</option>

                    <?php foreach ($wasteTypes as $type): ?>
                        <option value="<?php echo clean($type); ?>">
                            <?php echo clean($type); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <span class="rc-results"
                  id="rc-available-count"
                  role="status"></span>
        </div>

        <div class="rc-table-wrap"
             tabindex="0"
             role="region"
             aria-label="Available recyclable waste table">
            <table>
                <thead>
                    <tr>
                        <th scope="col">Waste Listing</th>
                        <th scope="col">Material Type</th>
                        <th scope="col">Location</th>
                        <th scope="col">Collection</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach ($available as $report): ?>
                        <tr
                            class="rc-available-row"
                            data-search="<?php echo clean(
                                $report["id"] . " " .
                                $report["title"] . " " .
                                $report["location"]
                            ); ?>"
                            data-type="<?php echo clean($report["waste_type"]); ?>"
                        >
                            <td>
                                <strong>
                                    <?php echo clean($report["title"]); ?>
                                </strong>

                                <span class="rc-subtext">
                                    Report #<?php echo (int) $report["id"]; ?>
                                </span>
                            </td>

                            <td>
                                <?php echo clean($report["waste_type"]); ?>
                            </td>

                            <td>
                                <?php echo clean($report["location"]); ?>
                            </td>

                            <td>
                                <form action="recycler_action.php" method="POST">
                                    <input type="hidden"
                                           name="action"
                                           value="request">

                                    <input type="hidden"
                                           name="report_id"
                                           value="<?php echo (int) $report["id"]; ?>">

                                    <button
                                        type="submit"
                                        class="rc-btn"
                                        aria-label="<?php echo clean(
                                            "Request collection for " . $report["title"]
                                        ); ?>"
                                    >
                                        Request Collection
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                    <tr id="rc-available-empty"
                        <?php echo $available ? "hidden" : ""; ?>>
                        <td colspan="4" class="rc-empty">
                            <?php echo $available
                                ? "No listings match your search."
                                : "No recyclable waste is currently available."; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>

    <!-- Recycling records -->
    <section class="rc-panel" id="rc-records">
        <div class="rc-panel-head">
            <div>
                <h2>My Recycling Records</h2>
                <p>
                    Open a record to enter its weight, update its status
                    and add recycling notes.
                </p>
            </div>

            <span class="rc-count">
                <?php echo count($records); ?>
            </span>
        </div>

        <div class="rc-tools" id="rc-record-tools" hidden>
            <div class="rc-field rc-search">
                <label for="rc-record-search">Search your records</label>
                <input
                    type="search"
                    id="rc-record-search"
                    placeholder="Search ID, title or waste type"
                >
            </div>

            <div class="rc-field">
                <label for="rc-status-filter">Recycling Status</label>

                <select id="rc-status-filter">
                    <option value="">All statuses</option>

                    <?php foreach ($recyclingStatuses as $status): ?>
                        <option value="<?php echo clean($status); ?>">
                            <?php echo clean($status); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <span class="rc-results"
                  id="rc-record-count"
                  role="status"></span>
        </div>

        <div class="rc-record-list">
            <?php foreach ($records as $record): ?>
                <?php
                $recordId = (int) $record["id"];
                $currentStatus = (string) $record["recycling_status"];
                $quantity = $record["quantity_kg"] ?? "";
                ?>

                <details
                    class="rc-record"
                    data-search="<?php echo clean(
                        $recordId . " " .
                        $record["title"] . " " .
                        $record["waste_type"]
                    ); ?>"
                    data-status="<?php echo clean($currentStatus); ?>"
                >
                    <summary>
                        <span class="rc-record-name">
                            <span class="rc-record-title">
                                <span class="rc-record-id">
                                    #<?php echo $recordId; ?>
                                </span>
                                <?php echo clean($record["title"]); ?>
                            </span>

                            <span class="rc-subtext">
                                <?php echo clean($record["waste_type"]); ?>
                                · <?php echo clean($record["location"]); ?>
                            </span>

                            <span class="rc-record-tags">
                                <span class="rc-badge <?php
                                    echo $badgeClass($currentStatus);
                                ?>">
                                    <?php echo clean($currentStatus); ?>
                                </span>

                                <span class="rc-quantity">
                                    <?php if ($quantity !== ""): ?>
                                        <?php echo number_format(
                                            (float) $quantity,
                                            2
                                        ); ?> kg
                                    <?php else: ?>
                                        Weight not entered
                                    <?php endif; ?>
                                </span>
                            </span>
                        </span>
                    </summary>

                    <form action="recycler_action.php"
                          method="POST"
                          class="rc-record-form">

                        <input type="hidden" name="action" value="update">

                        <input type="hidden"
                               name="report_id"
                               value="<?php echo $recordId; ?>">

                        <div class="rc-form-grid">
                            <div class="rc-field">
                                <label for="rc-quantity-<?php echo $recordId; ?>">
                                    Quantity in kg
                                </label>

                                <input
                                    type="number"
                                    id="rc-quantity-<?php echo $recordId; ?>"
                                    name="quantity_kg"
                                    step="0.01"
                                    min="0"
                                    placeholder="e.g. 25.50"
                                    value="<?php echo clean((string) $quantity); ?>"
                                    aria-describedby="rc-quantity-help-<?php echo $recordId; ?>"
                                >

                                <p class="rc-help"
                                   id="rc-quantity-help-<?php echo $recordId; ?>">
                                    Enter the material weight in kilograms.
                                </p>
                            </div>

                            <div class="rc-field">
                                <label for="rc-status-<?php echo $recordId; ?>">
                                    Recycling Status
                                </label>

                                <select
                                    name="recycling_status"
                                    id="rc-status-<?php echo $recordId; ?>"
                                    required
                                >
                                    <?php if (!in_array(
                                        $currentStatus,
                                        $recyclingStatuses,
                                        true
                                    )): ?>
                                        <option value="" disabled selected>
                                            Select a status
                                        </option>
                                    <?php endif; ?>

                                    <?php foreach ($recyclingStatuses as $status): ?>
                                        <option
                                            value="<?php echo clean($status); ?>"
                                            <?php echo $currentStatus === $status
                                                ? "selected" : ""; ?>
                                        >
                                            <?php echo clean($status); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="rc-field rc-full">
                                <label for="rc-note-<?php echo $recordId; ?>">
                                    Recycling Note
                                </label>

                                <textarea
                                    name="recycling_note"
                                    id="rc-note-<?php echo $recordId; ?>"
                                    placeholder="Add collection details, processing notes or the recycling outcome."
                                ><?php echo clean(
                                    $record["recycling_note"] ?? ""
                                ); ?></textarea>
                            </div>
                        </div>

                        <div class="rc-form-footer">
                            <button type="submit" class="rc-btn">
                                Save Record Changes
                                <span aria-hidden="true">→</span>
                            </button>
                        </div>
                    </form>
                </details>
            <?php endforeach; ?>

            <p class="rc-empty"
               id="rc-record-empty"
               <?php echo $records ? "hidden" : ""; ?>>
                <?php echo $records
                    ? "No records match your search."
                    : "You do not have any recycling records yet. Browse available waste to request a collection."; ?>
            </p>
        </div>
    </section>

</div>

<script>
(() => {
    "use strict";

    function setupFilter(options) {
        const search = document.getElementById(options.searchId);
        const filter = document.getElementById(options.filterId);
        const counter = document.getElementById(options.counterId);
        const empty = document.getElementById(options.emptyId);
        const toolbar = document.getElementById(options.toolbarId);

        const items = Array.from(
            document.querySelectorAll(options.selector)
        );

        if (!search || !filter || !counter || !empty || !toolbar) {
            return;
        }

        function applyFilter() {
            const query = search.value.trim().toLocaleLowerCase();
            const selectedFilter = filter.value;

            let visibleCount = 0;

            items.forEach((item) => {
                const searchableText =
                    (item.dataset.search || "").toLocaleLowerCase();

                const matchesSearch = searchableText.includes(query);

                const matchesFilter = !selectedFilter ||
                    item.dataset[options.filterKey] === selectedFilter;

                const visible = matchesSearch && matchesFilter;

                item.hidden = !visible;

                if (visible) {
                    visibleCount++;
                }
            });

            empty.hidden = visibleCount !== 0;

            counter.textContent =
                `${visibleCount} of ${items.length} shown`;
        }

        toolbar.hidden = false;

        search.addEventListener("input", applyFilter);
        filter.addEventListener("change", applyFilter);
        window.addEventListener("pageshow", applyFilter);

        applyFilter();
    }

    setupFilter({
        searchId: "rc-available-search",
        filterId: "rc-type-filter",
        counterId: "rc-available-count",
        emptyId: "rc-available-empty",
        toolbarId: "rc-available-tools",
        selector: ".rc-available-row",
        filterKey: "type"
    });

    setupFilter({
        searchId: "rc-record-search",
        filterId: "rc-status-filter",
        counterId: "rc-record-count",
        emptyId: "rc-record-empty",
        toolbarId: "rc-record-tools",
        selector: ".rc-record",
        filterKey: "status"
    });
})();
</script>

<?php require "footer.php"; ?>